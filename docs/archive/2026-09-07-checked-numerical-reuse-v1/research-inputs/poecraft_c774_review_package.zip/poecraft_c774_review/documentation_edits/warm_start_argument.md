<a id="current-query-warm-start"></a>
## Current-query numerical reuse is not certificate reuse

This is a proposed numerical optimization contract. The reviewed implementation
checks each phase candidate against a rebuilt frozen quotient, then calls a solve
that initializes modeled coordinates at zero. No warm-start feature is claimed
implemented by this section.

Let T be the Bellman operator of one fixed finite, action-complete lower query,
with fixed boundary values. If h is nonnegative, has the required terminal and
boundary values, and h <= T(h), monotonicity gives

    h <= T(h) <= T(T(h)) <= ... .

For synchronous exact Bellman updates this proves a monotone sequence of
subsolutions. It does not prove finite termination, uniqueness, attainment of the
proper-policy optimum, or correctness of an arbitrary numerical update. An
in-place update or algebraic self-loop elimination needs its own corresponding
premises, or its result must remain an untrusted proposal until checked.

The identity of the current query is essential. A native-admissible value may
fail a more optimistic truncated query, as explained in
[initialization](#initialization). A vector with the right length but the wrong
coordinate order is not the same potential. Prices, boundaries, action cover,
coefficient interpretation and relevant source/model generations must agree.

The phase producer also has a second distinction. Let F_y be the frozen quotient
constructed by choosing event/occupancy minima using vector y. Its selected
coefficients need not minimize expectation for another vector x. Therefore

    x <= F_y(x)

does not alone establish the native probability-envelope inequalities at x.
They must be reconstructed/minimized for x and checked with complete native
coverage. Numerical reuse must not reuse the previous outcome selection as native
authority. See [CLM-0014](../claims.md#clm-0014).

A current-query checked vector is the simplest eligible numerical seed. If most
outer-round vectors fail the rebuilt query, that optimization may save little.
Measure eligible rounds and their numerical cost before predicting its benefit.
A rejected vector may be used only as an explicitly untrusted numerical proposal
when the update method supports it; it cannot bypass checking. A bounded cold
fallback remains available, and its time/work counts toward the treatment.

Seed acceptance is not a stopping criterion. When a scalar floor of 10 has been
replaced by a complete relation allowing 100, the old value 10 can remain feasible.
The numerical query must still attempt the improvement. Zero-cost loops provide
another warning: with T(x)=min(x,5), every x in [0,5] is a fixed point, while the
proper-policy value is 5. Do not make a convergence guarantee by changing only
the initializer.

The implementation consumer must remain the existing lower query and phase
producer. The reference arguments are [CLM-0007](../claims.md#clm-0007),
[CLM-0013](../claims.md#clm-0013), [CLM-0014](../claims.md#clm-0014), and
[CLM-0023](../claims.md#clm-0023). Any new claim identity is assigned during intake;
this proposed section does not change those immutable statements or their status.
