"""Exact, mechanics-independent checks for a proposed lower-query warm start.
This is NOT a native poecraft2 run or a performance prediction.
Run with Python 3.11+: python warm_start_reference.py
"""
from fractions import Fraction as F
import json
from pathlib import Path


def bellman(v):
    # A finite proper two-state chain: x=1+y/2, y=2+x/2.
    return (1 + v[1] / 2, 2 + v[0] / 2)


def feasible(v):
    rhs = bellman(v)
    return all(F(0) <= a <= b for a, b in zip(v, rhs))


def solve(seed, eps=F(1, 10**9)):
    target = (F(8, 3), F(10, 3))
    v = seed
    assert feasible(v)
    for n in range(200):
        if max(abs(a-b) for a, b in zip(v, target)) <= eps:
            return n, v
        w = bellman(v)
        assert all(b >= a for a, b in zip(v, w)) and feasible(w)
        v = w
    raise AssertionError('Reference iteration cap')


def run():
    checks = []
    cold_n, cold = solve((F(0), F(0)))
    warm_seed = (F(2), F(3))
    warm_n, warm = solve(warm_seed)
    assert warm_n < cold_n
    checks.append({'name': 'current-operator feasible seed', 'passed': True,
                   'cold_sweeps': cold_n, 'warm_sweeps': warm_n,
                   'note': 'Toy iteration counts only; exact inequalities at every iterate.'})

    # Native admissibility does not establish feasibility in a truncated model.
    native_lower = F(10)
    truncated_rhs = F(1) + F(0)
    assert native_lower > truncated_rhs
    checks.append({'name': 'old native lower can fail the current query', 'passed': True})

    # A previously minimizing event allocation is not a valid new minimizer.
    old_p, new_p = (F(3,5), F(2,5)), (F(2,5), F(3,5))
    old_values, new_values = (F(0),F(10)), (F(10),F(0))
    dot = lambda p,v: sum(a*b for a,b in zip(p,v))
    assert dot(old_p,old_values)==4 and dot(old_p,new_values)==6 and dot(new_p,new_values)==4
    assert F(5) <= dot(old_p,new_values) and F(5) > dot(new_p,new_values)
    checks.append({'name': 'final-native re-minimization cannot be skipped', 'passed': True})

    # Sound fixed point does not imply the proper optimum or a unique fixed point.
    raw_T = lambda x: min(x, F(5))
    assert raw_T(F(0))==0 and raw_T(F(3))==3 and raw_T(F(5))==5
    checks.append({'name': 'zero-cost-loop fixed-point ambiguity', 'passed': True,
                   'raw_total_cost_optimum': '0', 'proper_policy_optimum': '5'})

    # A valid seed must not terminate refinement immediately after a floor is lifted.
    before_T, after_T = lambda x: F(10), lambda x: F(100)
    seed = F(10)
    assert seed <= after_T(seed) and after_T(seed) > seed
    checks.append({'name': 'seed acceptance is not post-reactivation convergence', 'passed': True})

    # Finite warm iterations started above the answer can remain infeasible.
    x=F(9)
    for _ in range(20):
        x=1+x/2
    assert x>2 and x>1+x/2
    checks.append({'name': 'untrusted high seed still requires final checking', 'passed': True,
                   'positive_residual': str(x-(1+x/2))})

    # Dense vectors must be mapped by semantic coordinate, not iteration order.
    keyed={'s':F(2),'t':F(3)}
    old_order=['s','t']; new_order=['t','s']
    mapped=[keyed[k] for k in new_order]
    assert mapped == [F(3),F(2)] and mapped != [keyed[k] for k in old_order]
    checks.append({'name': 'coordinate-aware seed mapping', 'passed': True})

    # Compiler/runtime numeric contracts are not replaced by an arbitrary tolerance.
    a=F(1); b=a-F(1,10**12)
    assert a != b and abs(a-b) < F(1,10**9)
    checks.append({'name': 'numeric difference must use its declared contract', 'passed': True})

    total=F('40.321'); numeric=F('18.272'); other=total-numeric
    max_speedup=total/other
    half_numeric_total=other+numeric/2
    checks.append({'name':'Amdahl attribution arithmetic','passed':True,
                   'archived_compact_total_seconds':str(total),
                   'archived_numeric_seconds':str(numeric),
                   'ideal_numeric_only_speedup_ceiling':float(max_speedup),
                   'total_if_numeric_halves_seconds':float(half_numeric_total),
                   'reduction_if_numeric_halves_fraction':float(1-half_numeric_total/total),
                   'note':'Algebra on archived stage times, not measured treatment performance.'})
    return {'scope':'exact synthetic mathematics and arithmetic, no native code executed',
            'checks':checks,'passed':len(checks),'failed':0}

if __name__=='__main__':
    result=run()
    target=Path(__file__).with_name('warm_start_reference_results.json')
    target.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))
