# Checked numerical reuse, trustworthy research views, and documentation closeout
## Sequential implementation plan v1

Repository: `OliverOrton/poecraft2`  
Reviewed main: `c77422c0cdfaf5f9caa57b52755841cadc91ac8a`  
Prepared: September 6, 2026  
Execution: one sequential Codex session at a time; **no subagents or delegated sessions**.

This plan continues the completed backbone and filter-continuation work. It does
not repeat the mathematical-reference programme or activate another filter model.
The user has selected the review, remaining cleanup and next solver work together.
On receipt, record the concise boundary and continue into implementation rather
than returning another planning-only document. Preserve coherent checkpoints when
a session ends. No push or public action is authorized.

## 1. Objective and priorities

Primary project objective: extend **certified exact closure**. This boundary makes
the already checked retention model cheaper to use, then tests a real compatible
solver outcome. A lower/preparation improvement is not automatically a new exact
solve or an end-to-end speedup.

In order:

1. Apply the authored current-document corrections and preserve the original
   report/knowledge delta. Do not consume a whole solver session on cosmetic edits.
2. Check the lower-only initialization/properness contract narrowly; leave broader
   GAP-01/05 applications explicitly open unless actually reconciled.
3. Implement and measure compatible numerical reuse across phase-model rounds,
   preserving complete final native reoptimization and checking.
4. Carry a qualifying result through the existing ordinary opt-in and one suitable
   exact-closure development comparison, without changing target/caps.
5. Finish the small context/report/CI gaps identified in the review, update the
   resulting documents, and return the actual knowledge receipt.

Do not reopen the removed lookup cache, build more filter modes, alter the
ordinary scheduler, replace the quotient, or create another experiment service.

## 2. Pinned evidence — do not repeat completed milestones

The backbone archive records substantive chapters, CLM-0001–0025, ten conditional
self-review acceptances, fifteen open claims, reference calculations, reporting,
intake/context tooling and actual carrier-header removal. It is not a blanket
native correctness proof. The fragment verifier has live consumers and was kept.

The filter-continuation archive records:

| Quantity | Recorded retained result |
|---|---:|
| Primary anchored lower/model/portfolio | 352.3101703388 |
| Prefix-removed source | 355.4326545436 |
| Coupled unfractured entry | 404.9953021064 |
| Mandatory programs | 355.7898136611 / 358.8722957137 |
| Compact preparation | 40.321 s |
| Relations / numerical solve / checking | 20.080 / 18.272 / 1.782 s |
| Rounds / numerical sweeps | 56 / 24,836 |
| Final native relations | 26,259 |
| Additional peak | 31,578,332 bytes, within 32 MiB |
| Ordinary additional preparation | 40.244 s |
| Ordinary total setup | 44.410 s |
| Ordinary 60-second off/on rows | 64,914 / 40,289 |
| Ordinary verified upper / exact completion | Neither observation supplies one |

These are archived measurements. They are not targets to force by changing
scope, an empty clean-five lower, or a claim that the treatment saves proof work.
The optimistic 51-state policy already caps this current model near the checked
values; more work on the unchanged filter relation cannot break that ceiling.

Source starting points:
- `docs/archive/2026-09-06-solver-mathematical-backbone-v2/README.md`
- `docs/archive/2026-09-05-native-metamod-first-exit-v1/README.md`
- `engine/src/solver_phase_probability.cpp`, current-query check and cold repair
- `engine/src/solver_quotient_lower.cpp`, `run_lower`, `solve_lower`, `check_lower`
- `engine/src/solver_sparse_policy.cpp`, row-local self/observed-choice evaluation
- `docs/solver/claims.md`, particularly CLM-0007, 0013, 0014, 0021, 0023/0024

## 3. Preflight and source intake

Read current AGENTS/HANDOFF and the relevant owners, not the entire archive.
Record actual HEAD, relevant unpushed changes and dirty paths. The reviewed commit
is a baseline, not permission to discard newer work. Do not reset, clean or
inspect/stage/change protected path `0`.

Preserve this package's report and actual calculation files once as research
input. Map each knowledge-delta item to incorporated/open/duplicate/refuted/
out-of-scope/blocked with a reason. New research propositions do not inherit
`accepted` merely because an assistant wrote them.

The document replacements describe **current reviewed behavior**, not a completed
warm-start feature. The optional staging utility does not edit a checkout. Apply
full replacements or the exact authored edits only after checking their base;
reconcile newer local text rather than forcing a failed hunk. During execution,
HANDOFF must describe the active local boundary rather than copying the supplied
review-time inactive state verbatim.

## 4. Authored documentation repair — finish the existing migration

Use `document_replacements/` and `documentation_edits/edits.json`. Preserve
historical source-basis citations, archive bytes and all claim statements,
preconditions and existing history events.

Required corrections:
- Current tools and integration are no longer merely proposed. Replace prospective
  wording in live mechanism pages, mathematical reading guidance and the claim
  introduction. Do not manufacture closure of GAP-01–05.
- Use current relative links for current source-owner navigation. Retain pinned
  links for historical evidence and the source of a derivation.
- Record completed independent reference work accurately: 33 synthetic examples
  and eight saved micro coefficient/reference checks, not new native qualification.
- HANDOFF owns current sequencing and actual push/local visibility. It must not
  call an already pushed snapshot local-only.
- Explain the current exact-profile limitations rather than promising an adapter
  for all native proof paths.
- Do not hand-edit `research-state.md`; repair its generator/metadata and regenerate.

The package supplies four full replacement pages and 22 exact edits over 18
additional existing paths, plus a proposed warm-start argument section. If a
local page no longer matches, use the authored replacement passage as a merge
input and record the precise conflict. This is not authorization to apply stale
full-page replacements over another session's edits.

The documentation map and shared instructions are already lean. Keep them. Do
not rerun the completed dead-header removal or delete active fragment/reference
code merely to produce another cleanup statistic.

## 5. Solver contract: numerical seed versus accepted certificate

### 5.1 The concrete current seam

`prepare_probabilistic` currently:

1. builds current candidate-specific event minima, allocations and frozen rows;
2. maps the candidate into the current dense graph coordinates;
3. calls `check_lower(query, dense_candidate, budget)`;
4. after price-floor handling, releases that result;
5. calls `solve_lower(query, budget)`, whose numerical proposal starts from zero
   on modeled states even when step 3 passed.

Do not change `check_lower` into a solver or treat passing step 3 as completion.
Temporary price-floor reactivation can leave an older, weaker candidate feasible.
The current model must still be numerically improved and the outer native relation
reconstructed for the final vector.

### 5.2 Narrow mathematical check

For a fixed monotone Bellman operator T and a feasible h <= T(h), exact synchronous
updates preserve nondecreasing subsolutions. That is a sufficient argument for
one class of initializer/update, not a universal convergence theorem. The actual
shared evaluator algebraically eliminates local self choices; verify its relevant
premises or keep its numerical output untrusted until the existing checker passes.

A zero-cost loop plus a paid finish has multiple Bellman fixed points. A valid
finite lower is not a claim to the greatest fixed point, proper-policy optimum,
infeasibility or public exact closure. Preserve this distinction in GAP-01 and
CLM-0001/0007. Do not change public objective semantics to simplify initialization.

A frozen probability allocation built at y can be non-minimizing at x. The final
phase producer must rebuild all value-dependent minima and capacities' minimizing
allocations for x and check the complete native relation. A current frozen-graph
certificate is not an all-vector native kernel.

### 5.3 Measure seed eligibility before predicting speed

Add compact per-round aggregate attribution using the already performed check:
- current candidate check passed/failed;
- sweep/time/work spent in those two populations;
- seed identity/mapping acceptance and refusal reason;
- cold fallbacks and their full work/time;
- final outer rounds, bound and relation/checking scope.

Do not retain a second full graph, per-row historical log or large dump of every
iterate. A current-query-feasible seed may apply only in late rounds. If that
population owns little of the 18.272 s, report it and take the permitted narrower
follow-through below; do not announce a speedup from the seam alone.

### 5.4 First implementation: current-query checked seed

Add an internal optional numerical-initializer path to the existing lower solver.
Keep current cold defaults and public ABI unchanged.

Reuse a finite current-query checked vector only after binding:
- request, caller scope and coefficient convention;
- current query/model and price/source/target generations;
- full source semantic-coordinate mapping (not length or order alone);
- terminal and independent-boundary values;
- current canonical action/family coverage.

Prefer borrowing the existing dense candidate or transferring its small vector.
A checked-seed token can identify the exact current query; do not keep an old
query/graph alive merely to avoid one vector copy. Charge any retained and scratch
buffers under the existing 32 MiB / total solver envelope.

The existing current check should not be needlessly repeated just to wrap the
seed in another type, but no naked Boolean may stand in for incompatible query
identity. An initializer rejection takes the unchanged cold route.

Preserve all existing final finite/nonnegative, boundary, exact-dot inequality,
staleness, cancellation and native coverage checks. A seed must never be returned
as authority before those checks and final native re-minimization.

### 5.5 One conditional follow-through, not a solver replacement

If current-query-feasible seeds miss most costly rounds, investigate the prior
compatible phase vector as an **untrusted numerical proposal**, not a certificate.
This is permitted only after tracing the update method's assumptions and testing
its behavior on current finite models, stale identities and zero-cost components.
No assertion `x >= old_native_lower` is added to an incompatible local model.

Keep work bounded by the existing query budget. Refuse nonfinite/invalid results
or take one explicit cold fallback; count all attempted work and do not gain
extra hidden budgets. Do not repeatedly run warm and cold until a lucky result
qualifies. If this requires another policy-iteration/LP/SCC framework, stop that
route and report its limitation. Reuse already-owned sparse facilities only.

Old row allocations, observed choices, or model certificates never follow the
untrusted vector into authority. The final checking conditions remain unchanged.

## 6. Focused tests and decisive native measurement

Use the existing proof-only selectors; inspect a selector before invoking it so
it cannot silently start Simulator. Add only tests required by the new contract:

- same-query warm/cold solutions on a small proper cyclic model;
- a valid target lower that fails a changed truncated query;
- current-coordinate mapping after ordering/identity changes;
- changed price, boundary, action scope and coefficient convention;
- zero-cost non-goal cycle plus a paid exit (lower validity versus optimality);
- genuine self/observed-choice behavior through the shared sparse evaluator;
- stale event minima/allocations rejected by final native reconstruction;
- feasible old value after a temporary floor is removed must still improve;
- current-query cancellation, resource refusal and cold fallback accounting;
- once-only setup and no additional production/default activation.

The package's exact calculations are explanatory inputs, not substitutes for
those affected native tests. Reuse existing fixtures where they already cover an
obligation; do not add a second unrelated toy catalogue.

### Matched compact experiment

After the implementation is coherent, run cold and warm in the same new executable
on the saved model, identical request, 32 MiB proof / 1 GiB total budgets and
native semantics. The option changes only numerical initialization. Include all
checks, rejected warm work and fallback cost.

Verify both saved exact sources, coupled entry, mandatory programs and complete
coverage. Values must be no weaker beyond the established recorded comparison
contract, with any numerical differences and their certificates disclosed.
Byte identity is welcome but not substituted for semantic/numerical validation.
No action may disappear to preserve a benchmark value.

Report relation construction, numerical solve, checking, export and full wall
time separately, plus outer rounds/sweeps, actual memory and final native relation
identity. Native pool construction is not the measured bottleneck here.

Numerical work is 18.272 of 40.321 archived seconds. Even eliminating all of it
would give at most about 1.83x total improvement if other work is unchanged.
Halving it would give about 31.185 s total (22.66% reduction). These are attribution
calculations, not predictions. Do not set an impossible twofold total gate for a
numerical-only change.

Before the treatment, lock a materiality criterion using the new matched control:
recommended >=15% total preparation reduction at equivalent checked strength and
no worse budgets. Also report the continuous outcome if it misses that target.
Archive comparison to old timing is contextual; primary performance evidence is
the same-executable pair. Repeat only to resolve observed timing ambiguity.

### Ordinary consumer and exact-closure connection

If compact preparation materially improves, run the matched existing ordinary
opt-in comparison once with all setup included. No public default is enabled.
A stronger/faster lower is an ordinary-bound milestone, not a speedup if neither
run reaches an equivalent proof/gap/solution milestone.

Then select **one existing development case** in the supported anchored/two-sided
domain whose retained evidence supplies a finite verified upper or a tractable
exact baseline. Pin case, policy scope, horizon and memory before the treatment;
use retained baseline artifacts only when their full comparison identity matches.
If needed, run one fresh matched baseline. Do not silently retune frozen_test or
pair the anchored lower with the empty clean-five upper.

Measure time/work to the same verified target, gap or exact result, with total
preparation included. If there is no suitable eligible case or the pair remains
without an incumbent, report that limitation rather than inventing an exactness
improvement. Do not substitute a whole new corpus-generation project.

## 7. Small remaining backbone/tooling fixes

These finish concrete omissions, not another documentation infrastructure project.
Keep old CLI/schema behavior and the strong measurement layer.

### 7.1 Portable selected context

Extend the current `solver_knowledge context` output with the actual source
revision, source/working-copy visibility and canonical repository link base.
Resolve current relative links for a committed export to that pinned revision;
leave historical pinned sources and external literature unchanged. An uncommitted
view must be labelled and either include the needed bounded text or refuse to
pretend that a pushed link contains it. Do not auto-fetch, push or expose unrelated
paths. Preserve complete selected preconditions and transitive-premise warnings;
keep explicit refusal rather than truncation at the size limit.

Do not build semantic search, another package format or an automatic theorem
reviewer. Where the linter does not enforce a selected-boundary or supersession
check, either add a small explicit testable check or document its real limits.
A missing assertion must not be described as enforced.

### 7.2 Generated research-state attribution and completeness

Keep `build_research_report` and existing saved adapters. Present first selected
optimistic action separately from a **proved limiter/ceiling**. Do not infer the
latter from the former. Include the available preparation cost by stage and
explicit absence of end-to-end improvement; keep large family lists in the JSON
rather than dumping them into the main table.

Add the originally requested compact RQ-001 exact-reference/availability view
from existing evidence. Distinguish native exact references, policy uppers and
missing matched performance. A documented historical result may be linked without
being re-certified or counted as a fresh outcome. Do not convert an archive README
into a fictitious complete benchmark report. Use one small explicit availability
adapter if required; no new database or corpus run.

Generated views must reproduce exactly from declared inputs. Add a cheap freshness
comparison in the existing knowledge CI job; do not hand-edit generated output.

### 7.3 Exact-profile evidence coverage

Current v1 requires strict-lift evidence and exact equality of parsed endpoint
fields. It can conservatively undercount otherwise valid native result paths.
Do not fix this by accepting `exact` strings alone or choosing a broad epsilon.

First document the v1 coverage (the supplied replacement does so). Inspect actual
native proof issuers and saved small reports. If adding a v2 adapter, enumerate
supported proof-source contracts explicitly, use the appropriate issued numerical
reconciliation, retain artifact/properness/action-scope evidence, and classify
unsupported evidence separately from contradicted evidence. Keep every planned
case in the denominator. Preserve v1 output meaning.

Use actual corpus stratum when available and label item class as item class; do
not relabel the latter as a recovered generator stratum. These are reporting
changes, not permission to weaken native publication.

### 7.4 Documentation-only CI

The knowledge job exists, but the Windows workflow still builds/tests for every
push and PR. Add a small, tested conservative change classifier at job/step level
if repository configuration permits it. Known prose/comment-metadata-only changes
may skip unrelated native work; unknown, mixed, build/data or C++ edits run the
existing appropriate validation. Do not infer a C++ change is comment-only from
its filename. Preserve required-check identities and honest not-applicable output;
never add an unconditional-success replacement or broad path filter leaving a
required workflow pending. No branch-protection changes are authorized.

## 8. Documentation at each technical checkpoint

The supplied pages are corrected for the reviewed current state. Update only the
sections whose implemented behavior this boundary actually changes. In particular:

- `lower-pruning.md`: actual warm initializer/default/fallback and retained authority;
- `mathematics/lower-bounds.md`: the reviewed argument and native qualification limits;
- claim history: actual responsible review and evidence, not invented independence;
- `research.md`: only genuinely resolved GAP applications, new findings and next question;
- `benchmarking.md`: the implemented report/context/profile commands and limitations;
- `research-state.md`: regenerate from newly archived or declared results;
- HANDOFF: the real current executable step or completion state.

Keep immutable archive bodies and original research inputs unchanged. Pin historical
source links; use relative links for current navigation. Do not mechanically bump
all verification dates or declare every doc/source path freshly verified.

Finish with a bounded live-owner link/status audit over the edited solver,
mathematics, foundation, template and instruction pages. If an additional stale
fact is found, write its actual replacement with source evidence. Do not replace
a missing proof by a confident rewrite. Non-solver product/mechanic docs not audited
remain outside any blanket freshness claim; historical dates are not defects.

## 9. Acceptance, stopping, and final receipt

Retain the smallest qualified numerical change. A failed warm experiment may
remain a compact diagnostic finding; remove a nonqualifying new production path.
Do not enlarge caps, weaken final checks, revive a discarded cache, or introduce
another solver merely to hit the performance target.

A genuine objective/proof contradiction blocks only the dependent promotion and
must be reported with the exact source/example. A generic unresolved global gap
is not a reason to stop independent documentation and safe lower-only work.

The final output to Oliver includes:
- actual local HEAD, unchanged/changed default behavior and push status;
- what documentation was replaced, corrected, generated or deliberately retained;
- disposition of each imported finding and canonical argument references;
- warm eligibility, cold/warm costs, complete lower results and resource ownership;
- ordinary and exact-frontier outcomes without inflating their meaning;
- passed, failed, unavailable and unrun checks;
- the one next measured solver question.

Run focused tests when they answer a live uncertainty or validate retained code.
No routine Simulator, repeated full census, unrelated visual review or broad
intermediate suites. A final broader test is justified only by actual retained
source impact. A solver performance result is not required to claim a corrected
research view, and a corrected research view is not a solver performance result.

## Source provenance

All repository paths above were reviewed at the pinned c77422c commit; the original
archived experiments remain attributed to their recorded binaries/machines.
`review_report.md` and `source_manifest.json` provide the claim-to-source map.
Relevant primary external sources are Bertsekas' proper-policy SSP analysis
(arXiv:1711.10129; IEEE TAC 2018, DOI 10.1109/TAC.2018.2811781), Chatterjee et al.'s
finite-MDP fixed-point certificates (TACAS 2025, arXiv:2501.11467), and GitHub's
official required-workflow guidance. They support cautions and design principles;
they do not establish a native warm-start speedup or settle poecraft2's entire
properness/publication correspondence.
