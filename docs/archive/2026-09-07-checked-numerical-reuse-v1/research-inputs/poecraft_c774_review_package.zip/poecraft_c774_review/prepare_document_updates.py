"""Stage the authored documentation corrections; never edit a checkout.

python prepare_document_updates.py --repo PATH                  # validate only
python prepare_document_updates.py --repo PATH --output OUTSIDE # stage full files

Use only at the reviewed revision. A mismatch requires an explicit merge by the
repository-writing session; this utility never fetches, resets, commits or pushes.
It excludes all archives and protected path 0 from reads and writes.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import subprocess

BASE = 'c77422c0cdfaf5f9caa57b52755841cadc91ac8a'
FULL = (
    'HANDOFF.md',
    'docs/solver/mathematics/README.md',
    'docs/solver/research.md',
    'docs/solver/benchmarking.md',
)


def unchanged_at_base(repo: Path, relative: str, current: bytes) -> None:
    original = subprocess.check_output(['git', 'show', f'{BASE}:{relative}'], cwd=repo)
    # Windows checkout line endings are not a semantic edit. Nothing else is normalized.
    if current.replace(b'\r\n', b'\n') != original.replace(b'\r\n', b'\n'):
        raise ValueError(f'{relative}: working copy differs from reviewed bytes')


def path_inside(root: Path, relative: str) -> Path:
    p = (root / relative).resolve()
    if (not p.is_relative_to(root.resolve()) or p == (root / '0').resolve()
            or p.is_relative_to((root / 'docs/archive').resolve())):
        raise ValueError(f'Unsafe/noncurrent path: {relative}')
    return p


def apply_edits(text: str, edits: list[dict]) -> str:
    for edit in edits:
        count = text.count(edit['find'])
        if 'expected_count' in edit and count != edit['expected_count']:
            raise ValueError(f"{edit['path']}: expected {edit['expected_count']} exact passage(s), found {count}")
        if count < edit.get('minimum_count', 0):
            raise ValueError(f"{edit['path']}: expected at least {edit['minimum_count']} exact passage(s), found {count}")
        text = text.replace(edit['find'], edit['replace'])
    return text


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    repo, package = args.repo.resolve(), Path(__file__).resolve().parent
    if args.output and args.output.resolve().is_relative_to(repo):
        parser.error('--output must be outside the checkout; this tool does not edit it')
    head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
    if head != BASE:
        parser.error(f'Reviewed {BASE}, found {head}; reconcile the authored changes rather than force-applying them')
    spec=json.loads((package/'documentation_edits/edits.json').read_text(encoding='utf-8'))
    staged, issues = {}, []
    # Compare full replacements with both the committed blob and current bytes.
    for relative in FULL:
        try:
            source=path_inside(repo,relative)
            unchanged_at_base(repo, relative, source.read_bytes())
            staged[relative]=(package/'document_replacements'/relative).read_text(encoding='utf-8')
        except (ValueError,OSError,subprocess.CalledProcessError) as exc:
            issues.append(str(exc))
    for relative in sorted({e['path'] for e in spec['edits']}):
        try:
            source=path_inside(repo,relative)
            original=source.read_bytes()
            unchanged_at_base(repo, relative, original)
            relevant=[e for e in spec['edits'] if e['path']==relative]
            staged[relative]=apply_edits(original.decode('utf-8'),relevant)
        except (ValueError,OSError,subprocess.CalledProcessError) as exc:
            issues.append(str(exc))
    for addition in spec['append_sections']:
        relative=addition['path']
        try:
            text=staged[relative]
            if addition['absent_marker'] in text:
                raise ValueError(f'{relative}: appended argument already exists')
            text=text.rstrip()+'\n\n'+(package/addition['content_file']).read_text(encoding='utf-8')
            staged[relative]=text
        except (ValueError,OSError,KeyError) as exc:
            issues.append(str(exc))
    if issues:
        print(json.dumps({'status':'refused; no files written','issues':issues},indent=2))
        return 1
    report={'status':'validated authored edits, not semantic certification','base':BASE,
            'files':sorted(staged),'checkout_modified':False}
    if args.output:
        dest=args.output.resolve()
        if dest.exists() and any(dest.iterdir()):
            parser.error('staging output must be new or empty')
        for relative,text in staged.items():
            target=path_inside(dest,relative)
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_text(text,encoding='utf-8',newline='\n')
        report['output']=str(dest)
    print(json.dumps(report,indent=2))
    return 0

if __name__=='__main__':
    raise SystemExit(main())
