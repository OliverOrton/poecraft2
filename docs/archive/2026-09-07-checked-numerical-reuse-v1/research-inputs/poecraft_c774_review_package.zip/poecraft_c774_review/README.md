# c77422c review and next implementation packet

Start with `implementation_plan.md`; `review_report.md` supplies the source-backed
reasoning and knowledge delta. All repository evidence is pinned in
`source_manifest.json`.

## Authored documentation

`document_replacements/` contains complete reviewed-current drafts for:
- HANDOFF;
- solver research questions/workflow;
- benchmarking/report scope;
- mathematical reading guide.

`documentation_edits/edits.json` contains 22 exact replacement edits over 18 other
current pages, preserving substantive arguments and claim history.
`warm_start_argument.md` adds the proposed numerical-reuse reasoning, explicitly
not an implemented feature. These are not vague requests for Codex to author later.

`prepare_document_updates.py --repo CHECKOUT` validates the pinned source and
literal passages without writing. With `--output DIRECTORY_OUTSIDE_CHECKOUT` it
stages full updated files for review. It never edits the checkout, fetches,
resets, commits or pushes. It refuses newer/changed input, missing passages and
nonempty output. Reconcile a mismatch explicitly; do not force replacement.
The utility is a one-off packet aid, not a new repository service or dependency.
Its full-checkout application was not executed in the read-only research session.

The generated `research-state.md` is intentionally not supplied as hand-edited
replacement data. Change the existing generator/metadata and regenerate it.
Historical archive wording/hashes and registered claim propositions are not
rewritten. The writer must adapt HANDOFF to actual active local work.

## Calculations

Run `python checks/warm_start_reference.py`. It executes nine groups of exact,
mechanics-independent checks and attribution arithmetic. The recorded output is
included. No native engine was built or run, and no native speedup is predicted.

## Instruction for Codex

Implement the governing plan in one sequential session, without subagents.
Preserve user work and protected path 0; do not push. Apply the authored current
document corrections, retain the completed backbone, and investigate checked
numerical reuse at the current-query seam. Keep cold fallback, all final native
minimization/coverage checks and default-off behavior. Measure all preparation
cost and then one suitable actual solver outcome. Finish the narrow context,
reporting and docs-only CI gaps; do not build another framework or reopen the
rejected lookup cache. Return the actual claim/argument disposition, changes,
validation and local/push status.
