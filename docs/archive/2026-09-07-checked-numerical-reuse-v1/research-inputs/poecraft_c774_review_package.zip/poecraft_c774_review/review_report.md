# Backbone review and next solver decision

Reviewed: `OliverOrton/poecraft2` at `c77422c0cdfaf5f9caa57b52755841cadc91ac8a`,
September 6, 2026. Remote main remained at this revision at the final check.
The review is read-only. No native build, solver run, test suite, simulation,
repository edit, commit or push was performed. Exact synthetic checks and authored
replacement files are included separately.

## Decision

The backbone is a useful implementation, not merely scaffolding. Keep it. Complete
its remaining current-document and evidence-view details, then make the existing
native retention lower cheaper through checked numerical reuse. Do not turn the
whole next session into a five-gap audit or another filter/abstraction expansion.

The new solver hypothesis is specific: repeated lower-query solves discard a
currently available vector and restart modeled values at zero. Determine how much
current-query-compatible reuse is possible, then implement the smallest useful
numerical initializer without altering final native/probability checking.

The full implementation plan includes authored documentation repairs, tooling
finishing work, matched solver evidence and the handoff back into canonical docs.

## 1. What landed well

The [backbone archive](https://github.com/OliverOrton/poecraft2/blob/c77422c0cdfaf5f9caa57b52755841cadc91ac8a/docs/archive/2026-09-06-solver-mathematical-backbone-v2/README.md)
records the connected mathematical chapters, 25 claim identities, ten conditional
Codex self-review acceptances, fifteen open claims, question-linked reports,
selected-context/lint tools, 33 exact synthetic examples and eight micro
coefficient/reference checks. It distinguishes self-review from independent native
verification and keeps the coefficient mismatch visible.

The dead carrier-planner projection header and its sole self-descriptor reference
were removed after a local audit. The fragment verifier was retained because it
has real benchmark/test/tool consumers. That is a better outcome than deleting
something arbitrary to meet a cleanup quota.

The [documentation map](https://github.com/OliverOrton/poecraft2/blob/c77422c0cdfaf5f9caa57b52755841cadc91ac8a/docs/README.md)
is now a short map rather than a history book. The lower chapter contains actual
stopping, coverage, composition and event-minimization arguments. The measurement
layer and prior source evidence were retained. These are the parts to keep.

## 2. Newer solver evidence changes the next question

The [filter-continuation archive](https://github.com/OliverOrton/poecraft2/blob/c77422c0cdfaf5f9caa57b52755841cadc91ac8a/docs/archive/2026-09-05-native-metamod-first-exit-v1/README.md)
records an anchored source lower 352.3101703388, the second source 355.4326545436,
and a coupled unfractured entry 404.9953021064. Both selected filter kinds were
needed; the former 212 exit is not the current solver task.

The stronger construction takes 40.321 seconds in the compact probe: 20.080 in
relation construction, 18.272 in numerical solves and 1.782 in checking. There are
56 outer rounds, 24,836 sweeps and 26,259 final relations. The ordinary 60-second
pair spends 40.244 seconds in additional preparation, produces fewer ordinary
rows and finds no verified upper/exact completion in either observation.

This is a native-bound improvement, not a demonstrated end-to-end speedup. It
also must not be paired with the historical empty clean-five upper to invent a
gap. The scope remains the supported anchored request with a jointly modeled
fresh region, not every empty-item task.

The same archive measured and removed a lookup cache. Recommending that cache
again from an older high call count would repeat the very rediscovery problem
this backbone is meant to prevent.

## 3. Source-level numerical reuse opportunity

[The phase producer](https://github.com/OliverOrton/poecraft2/blob/c77422c0cdfaf5f9caa57b52755841cadc91ac8a/engine/src/solver_phase_probability.cpp)
constructs candidate-specific event minima and probability allocations, maps its
candidate to the current graph, and calls `check_lower`. After price-reactivation
handling it still invokes `solve_lower`, whose
[current implementation](https://github.com/OliverOrton/poecraft2/blob/c77422c0cdfaf5f9caa57b52755841cadc91ac8a/engine/src/solver_quotient_lower.cpp)
initializes modeled numerical values at zero.

A passing current-query check is useful seed evidence. A failed check is not.
The missing measurement is how many costly rounds have an eligible seed: if
only the final round does, feasible-only reuse may save little. The plan measures
that using the check already being executed rather than assuming every old
certificate transfers.

There is a safe separation to preserve:

    old/native-valid vector
        is not necessarily feasible for this truncated model;
    a current-query-checked vector
        can be an eligible numerical seed under the update contract;
    a numerical result for frozen rows
        still needs final native event minimization and checking.

The shared sparse updater performs algebraic self/observed-choice calculations,
not just a textbook synchronous update. Its initialization assumptions must be
checked, or the resulting vector kept untrusted until full acceptance. A small
seed type/API is sufficient; no second graph or general cache service is needed.

The proposed current-query lemma and its limits are authored in
`documentation_edits/warm_start_argument.md`. The existing CLM-0013/0014 argument
already rules out the unsafe shortcuts. New claim IDs are assigned by the writer
after review; this packet does not manufacture an accepted project claim.

## 4. What the literature changes—and does not

[Bertsekas, Proper Policies in Infinite-State SSPs](https://arxiv.org/abs/1711.10129)
(IEEE TAC 2018, DOI 10.1109/TAC.2018.2811781) shows that initialization can matter
for the Bellman solution reached under different proper-policy assumptions.
That supports explicitly testing zero-cost/properness semantics. It is not a
proof that this native initializer will converge, nor a reason to block every
lower-only improvement behind a whole-engine verification project.

[Chatterjee et al., Fixed Point Certificates for Reachability and Expected Rewards
in MDPs](https://arxiv.org/abs/2501.11467) (TACAS 2025) supports separating numerical
candidate generation from checked acceptance. Its finite-MDP checker does not
supply this engine's native action/member/probability bridge automatically.

The practical recommendation remains small: use the current checker, preserve
the final native relation, and change only numerical work where it demonstrably
costs time. Do not port another algorithm or theorem prover.

The synthetic arithmetic gives an important ceiling: if all non-numerical work
stays constant, deleting every numerical solve from the archived 40.321-second
construction yields at most about 1.83x total improvement. Halving numerical time
would give 31.185 seconds, a 22.66% reduction. Neither is a measured prediction.

## 5. Remaining documentation/tooling defects

### Live pages still describe completed integration as future work

The mathematical guide and claim introduction retain draft/provisional-integration
instructions. The benchmark page simultaneously says the tools are not yet
claimed implemented and documents their implemented commands. Numerical closure
still calls the independent reference slice planned. Several mechanism pages
share a final paragraph saying local correspondence must be reconciled during
integration despite the completed integration and explicit remaining gaps.

The packet supplies four full current-page replacements and exact authored
replacement passages for the other affected pages. This is not an instruction to
invent new prose later. Original arguments, statements, preconditions, histories
and archive bytes are preserved. Current navigation should point to current
owners; historical source-basis links remain pinned.

### Context export is usable but not fully portable

[`solver_knowledge.py`](https://github.com/OliverOrton/poecraft2/blob/c77422c0cdfaf5f9caa57b52755841cadc91ac8a/tools/ingest/poecraft_ingest/solver_knowledge.py)
now links selected dependency IDs to the complete claim ledger and states a local
link base. It does not include the actual source revision or make those local
links independently resolvable outside the checkout. Add that explicit provenance,
without fetching/pushing or implying access to uncommitted local work.

The linter checks metadata and references; it does not prove propositions or
fully enforce every prospective selected-boundary/supersession feature discussed
in the master plan. Document the actual scope, and add only a narrow missing
check where it is genuinely useful.

### Exact-closure reporting has a deliberately narrow adapter

[`exact_closure_profile`](https://github.com/OliverOrton/poecraft2/blob/c77422c0cdfaf5f9caa57b52755841cadc91ac8a/tools/ingest/poecraft_ingest/solver_reports.py)
requires strict-lift `global_lower_bound_closed` plus evaluation/status/resource
conditions, and exact equality of the parsed lower/upper/evaluated-cost fields.
This is conservative support for one report shape, not an exhaustive native
exactness reader. It could undercount other valid paths; this review does not
claim a demonstrated wrong classification of a particular saved result.

Document that boundary immediately. Any v2 must use actual native proof-source
and numerical contracts, not simply loosen equality or trust status strings.
The current grouping uses item class, so it must not be labelled generator stratum.

### Generated current state needs better causal attribution

The current RQ-002 view conflates a first selected action with a limiting reason
in places and can dump long family arrays into the main table. Separate policy
action, proved limiting constraint/ceiling and unavailable attribution. Add the
originally requested compact RQ-001 reference/availability view without inventing
missing reports or rerunning a large corpus. Keep exact outcome and lower-history
views distinct.

### Cheap CI should finish the original intent

The new knowledge workflow performs focused checks but does not compare generated
research-state freshness. The Windows workflow still builds/tests on every push
and PR. Add narrow regeneration and conservative docs-only work classification,
not another workflow that reports unconditional success.
[GitHub's official guidance](https://docs.github.com/en/actions/how-tos/write-workflows/choose-when-workflows-run/trigger-a-workflow)
warns that skipping a required workflow using path filters can leave its check
pending. Preserve honest job identities and outcomes.

## 6. Knowledge delta for Codex intake

| Temporary ID | Finding | Basis | Disposition to consider |
|---|---|---|---|
| P1 | A current-query check is followed by a zero-initialized numerical solve | Direct source observation | Link to implementation and measure eligible-round cost |
| P2 | Same-operator feasible warm starts preserve subsolution order for exact monotone updates | Derived sufficient argument, with algorithm/zero-cost qualifications | Review/merge into lower chapter; do not automatically claim native update convergence |
| P3 | Current-query numerical feasibility does not replace final native minimization | Existing argument plus synthetic counterexample | Reuse CLM-0013/0014; no duplicate theorem needed |
| P4 | Numerical-only speedup has a ~1.83x ceiling under fixed other costs | Exact arithmetic on archived stages | Scoped engineering constraint, not a treatment measurement |
| P5 | Implemented profile supports strict-lift report shape, not every proof source | Direct Python predicate review | Correct documentation, version any expansion |
| P6 | Several live pages still contain draft/integration-future wording | Current doc text | Apply authored editorial replacements, preserve histories |
| P7 | The previous lookup-cache lead has been measured and rejected in the new cost regime | Archived matched finding | Do not reopen without changed evidence |

No numerical optimization has been implemented or qualified by this review.

## 7. Risks, limits and stopping rule

The strongest objection is practical: warm-start eligibility might be rare, and a
much cheaper 352-cost lower may still fail to change the difficult solver's proof
work. The plan therefore measures both eligibility and a compatible ordinary/real
solver outcome. It does not let nine toy checks or a faster constructor stand in
for exact-closure progress.

This was a targeted live solver/backbone review, not an exhaustive audit of every
product/mechanic document, historical archive or numerical public mode. The common
boilerplate locations include indexed-search findings whose exact local passage
must be checked before replacement. The supplied staging utility refuses mismatches
and does not modify a checkout. No whole-repository freshness claim is made.

The corrected documents are current-state drafts prepared for Codex integration.
They do not silently mark GAP-01–05 resolved, alter runtime authority, or report
proposed tooling/solver changes as already installed. Final execution must update
the few affected behavior descriptions with actual results and leave all other
history intact.
