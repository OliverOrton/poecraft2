"""Structural checks for this documentation packet; not a theorem/code checker."""
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import re, json, hashlib, posixpath
from collections import Counter

ROOT=Path(__file__).resolve().parents[1]
previous=ROOT.parent/'poecraft_mathematical_docs_v1.zip'
# Standalone supplement requires the original package for cross-packet validation.
# In the combined packet all repo-drafts already share one root.
docs={}
if previous.is_file():
    with ZipFile(previous) as z:
        for name in z.namelist():
            if name.startswith('repo-drafts/') and name.endswith('.md'):
                docs[name[len('repo-drafts/'):]]=z.read(name).decode('utf-8')
for p in (ROOT/'repo-drafts').rglob('*.md'):
    docs[p.relative_to(ROOT/'repo-drafts').as_posix()]=p.read_text(encoding='utf-8')

def slug(s):
    s=re.sub(r'<[^>]+>','',s)
    s=re.sub(r'[`*_~]','',s).strip().lower()
    s=re.sub(r'[^\w\- ]','',s,flags=re.UNICODE)
    return s.replace(' ','-')

def anchors(text):
    explicit=set(re.findall(r'<a\s+id=[\"\']([^\"\']+)',text))
    ans=set(explicit); counter=Counter(); fenced=False
    for line in text.splitlines():
        if line.startswith('```'):
            fenced=not fenced; continue
        if fenced: continue
        m=re.match(r'^#{1,6}\s+(.+?)\s*#*$',line)
        if m:
            base=slug(m.group(1)); n=counter[base]; counter[base]+=1
            ans.add(base if n==0 else f'{base}-{n}')
    return ans

ids={k:anchors(v) for k,v in docs.items()}
claim_defs=set(re.findall(r'^## (CLM-\d{4})\b',docs.get('docs/solver/claims.md',''),flags=re.M))
failures=[]; resolved=[]; repo_dependencies=[]; external=[]
for name,text in docs.items():
    if text.count('```')%2:
        failures.append({'file':name,'error':'unbalanced_code_fence'})
    for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^\s)]+)(?:\s+"[^"]*")?\)',text):
        if re.match(r'(?:https?|mailto):',target):
            external.append({'file':name,'target':target}); continue
        filepart,sep,anchor=target.partition('#')
        dest=posixpath.normpath(posixpath.join(posixpath.dirname(name),filepart)) if filepart else name
        if dest.startswith('../'):
            failures.append({'file':name,'error':'outside_repo_link','target':target}); continue
        if dest in docs:
            if anchor and anchor not in ids[dest]:
                failures.append({'file':name,'error':'missing_draft_anchor','target':target,'destination':dest})
            else:
                resolved.append({'file':name,'target':target,'destination':dest})
        else:
            repo_dependencies.append({'file':name,'target':target,'destination':dest,'status':'check_in_actual_checkout'})
    for cid in set(re.findall(r'\bCLM-\d{4}\b',text)):
        if cid not in claim_defs:
            failures.append({'file':name,'error':'unknown_draft_claim','claim':cid})

new=[p.relative_to(ROOT/'repo-drafts').as_posix() for p in (ROOT/'repo-drafts').rglob('*.md')]
result={
 'scope':'Structural Markdown/link/claim-reference checks only; no native tests or proof verification.',
 'draft_documents_in_union':len(docs),'documents_in_this_tree':len(new),
 'declared_provisional_claims':len(claim_defs),
 'resolved_draft_links':len(resolved),'external_links_not_live_checked':len(external),
 'existing_repository_link_occurrences':len(repo_dependencies),
 'existing_repository_dependencies':sorted(repo_dependencies,key=lambda x:(x['destination'],x['file'])),
 'failures':failures,'passed':not failures,
}
(ROOT/'checks'/'document_checks.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('existing_repository_dependencies',)},indent=2))
if failures: raise SystemExit(1)
