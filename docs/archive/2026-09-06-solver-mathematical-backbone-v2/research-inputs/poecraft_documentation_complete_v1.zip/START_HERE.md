# Complete authored documentation for the pinned v2 plan

This combines the initial mathematical drafts with the supplemental mechanism/workflow rewrites. It changes neither the approved implementation plan nor the earlier mathematical text.

- `repo-drafts/`: **33 Markdown drafts** at their intended repository paths: the original 15 plus 18 additional replacement candidates.
- `integration-edits/`: four targeted append/merge inputs. They are not replacements for the historical ledgers or live HANDOFF.
- `pinned-plan/implementation_plan.md`: a byte-identical copy of the governing lean-operation v2 plan, verified by `PLAN_PIN.json`.
- `provenance/`: original packet maps and manifests. The first packet's original evidence/claim status remains intact.
- `checks/`: structural link/reference check plus the unchanged earlier mathematical example source/results. The examples were not rerun for this second drafting batch.

## Integration

Use the pinned plan. Add new mathematical owners and merge the mechanism/navigation replacements against the actual local revision. Do not copy the whole directory over the repository blindly. Preserve useful historical anchors and original evidence. The three optional agent definitions do not authorize subagents in this programme.

The claim IDs remain provisional and their histories remain open. New references to a claim are not an acceptance event. Reconcile source correspondence and explicit gaps before promotion. No engine, reporting, lint, CI, or retirement implementation is claimed by these documents.

Benchmark policy is written, but its series/reporting code remains planned at the reviewed snapshot. `docs-tooling-transition.md` is conditional on real tool integration. No `research-state.md` was fabricated.

The historical browser verification label is distinguished from shared engineering validation policy. The Lab still owns orchestration rather than solver answers. Obsolete milestone narration is removed from current mechanism drafts and linked to original evidence rather than silently rewritten.

## Review scope and checks

Reviewed repository snapshot: `OliverOrton/poecraft2` at `f3e7c0fa7bd827064a41c48a53c4db372840cf0f`. The second batch rewrites retained source contracts and selected current code evidence; it is not a full independent verification of all named implementation paths. No repository edit, engine build, native test/solve, Simulator, or subagent was used.

`checks/document_checks.json` records structural validation across the combined draft namespace. Existing repository targets/incoming anchors must still be reconciled in the checkout; external links were not exhaustively fetched. The pinned plan and all 15 original draft files are byte-identical to their supplied versions.

See `provenance/mechanism-docs-v1/INTEGRATION_MAP.md` for the additional file map and `provenance/mathematical-docs-v1/START_HERE.md` for the original mathematical draft scope. These are one-time intake aids, not future mandatory startup reading.

## Short instruction to Codex

> Integrate this authored content under the pinned lean-operation v2 plan. Reconcile local changes and provisional claims; preserve mathematical arguments and original evidence. Merge current mechanism/workflow replacements, apply append-only and conditional edits only where appropriate, and continue the selected tooling/reporting/reference/verified-cleanup implementation. Do not regenerate the docs from empty headings, silently accept draft claims, or claim that importing prose completes the programme. Do not push.
