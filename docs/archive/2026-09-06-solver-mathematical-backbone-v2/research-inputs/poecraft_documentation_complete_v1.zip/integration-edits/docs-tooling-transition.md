# Transition text for `docs/future/docs-tooling.md`

**Conditional integration edit.** The current placeholder says that documentation tooling is not implemented. The pinned v2 programme will add narrow claim/reference and context/report tools. This packet writes no tooling, so it must not claim those commands exist.

Once the actual module and commands are integrated, replace the placeholder with this short pointer, substituting only verified command names and the implementation evidence link:

> # Documentation Tooling
>
> The selected mathematical-backbone work now owns implemented claim/reference lint and bounded research context export. See [solver research](../solver/research.md) and the actual tool's help for available commands and limits.
>
> The check validates reference identity, status/dependency structure, and relevant links. It does not machine-check mathematical proofs or establish that code satisfies a cited theorem. It does not require a full-product build or routine simulation for prose changes.
>
> The older universal sorting, restamping, area-ownership, and reachability proposals below are not implied requirements. Adopt additional checks only for a demonstrated maintenance need; do not implement a second documentation framework.

If the old proposal has no remaining independent purpose or incoming reference, it may instead be removed after preserving its historical address through Git and repairing live links. Do not keep two roadmaps for the same implemented tool.

Before tooling exists, either leave the old page explicitly future-only or add a link to the selected implementation record. Do not publish command examples, CI enforcement, generated research-state content, or completed checks that are not available.
