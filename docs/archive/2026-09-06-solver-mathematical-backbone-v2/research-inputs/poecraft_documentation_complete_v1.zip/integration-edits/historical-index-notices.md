# Historical index notices — narrow merge edits

These are ready-to-use replacement introductory blocks, not full replacements for the historical documents. Preserve the existing section anchors, observations, evidence hashes, and dated conclusions beneath them. Do not rewrite a past “next” into current sequencing.

## `docs/evidence.md`

Replace only its current-authority introduction with:

> # Historical Evidence Index
>
> This page preserves historical observations and links to original artifacts. A statement labelled current or next inside an older entry describes that entry's recorded point in time; it does not own present sequencing or a current cross-run comparison.
>
> Use [solver research](solver/research.md) for durable questions and their evidence routes, [claims](solver/claims.md) for scoped propositions and falsifications, and [HANDOFF](../HANDOFF.md) when active work needs clarification. Generated question views, when implemented, identify their actual inputs and missing evidence.
>
> Keep existing entries and anchors intact. Do not append a new current-status narrative here for every boundary. Preserve the original evidence at its existing address and record only the relevant question/claim change in its canonical owner.

## `docs/solver/architecture-history.md`

Replace only the current/historical classification at the top with:

> # Historical Solver Architecture
>
> This reference preserves earlier architecture explanations and dated investigations. It is available for a specific historical question, not mandatory startup reading or current implementation authority.
>
> The present code-owner map is [Solver internals](../foundation/solver-internals.md). Mathematical arguments are organized in [mathematics](mathematics/README.md), while proposition histories and counterexamples live in [claims](claims.md). Retain the original sections below; superseded implementation advice remains historical rather than silently becoming a new plan.

## `docs/active/README.md`

Merge its directory-listing function with the following short ownership notice. Do not invent an active boundary from this packet:

> [HANDOFF](../../HANDOFF.md) identifies current implementation work when continuation needs clarification. This index links the actual active material; it does not repeat its status, measurements, or next-step narrative.
>
> An explicit owner request selects its task. Routine small fixes need no new boundary folder. A substantive multi-session task may use one living record; completion archives that record once, preserving its evidence and links.

## `docs/foundation/README.md`

Add or merge a single route, without copying chapter content:

> For the mathematical problem and correctness arguments behind the native implementation, use [Solver mathematics](../solver/mathematics/README.md). For file ownership and current execution boundaries, use [Solver internals](solver-internals.md).

## Other area `NOTES.md` or templates

Do not bulk rewrite them. Where a live rule requires deletion of disproved mathematical notes, replace that requirement with: preserve reusable counterexamples and original evidence; remove obsolete recommendations from the current reading path. A link to the canonical claim is enough once the finding has been incorporated.
