# Concrete policy and documentation conflicts to reconcile

This is a one-time integration note, not recurring task paperwork. It does not amend the pinned v2 plan.

| Original location | Source-supported issue | Draft treatment |
|---|---|---|
| `.claude/agents/test-pipeline.md` | Says Emscripten is absent and forbids `scripts/build-wasm.ps1`, despite the shared build policy using that script to activate the SDK | Replace the stale assertion with the actual configured-build/authorization check |
| `.claude/agents/data-auditor.md` | Repeats the absent-SDK assertion and treats DB/artifact modification time ordering as conclusive staleness | Treat timestamps as clues; use derivation/content identity and the current build route |
| `.claude/agents/doc-drift.md` | Hardcodes an old phase/document map and suggests automatic phase auditing | Make it an optional, task-scoped comparison; preserve argument versus implementation distinctions |
| `docs/foundation/solver-lab.md` | Ends by describing PDR as permanently resource-capped | Remove the timeless result claim; the Lab's capability is orchestration, while case results belong to versioned native evidence |
| `docs/solver/flow.md` | Calls the existing browser 10,000-run button the repository-required sample count | Preserve the actual UI label; separate it from current engineering validation policy |
| `docs/solver/upper-authority.md` | Lists `solver_executable_carrier_planner.*` as a primary issuer despite retained types being diagnostic future-use vocabulary | Do not name that projection as an upper issuer; source deletion still needs the local consumer audit |
| `docs/foundation/change-impact.md` | Requires widespread restamps/parent/evidence updates and retains old build/export details | Use actual impacted owners and inventories; no global restamping or broad audit for a small prose change |
| `docs/solver/benchmarking.md` | Says no primary comparison score has been selected | Record the owner's exact-closure objective while explicitly preserving legacy reporter/schema state until code changes land |

Do not change runtime defaults, the UI verification batch, an action's legality, or a numeric exactness tolerance to make prose agree. A source or semantic discrepancy needs its own disposition.

Keep the already supplied mathematical chapters, open claim histories, six named gaps, lean AGENTS draft, and pinned plan unchanged. These mechanism drafts provide source correspondence; they do not accept those claims by reference.
