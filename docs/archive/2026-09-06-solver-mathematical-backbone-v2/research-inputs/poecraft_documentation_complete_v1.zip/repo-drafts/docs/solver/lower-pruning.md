# Lower And Pruning Authority

**Integration draft.** Rewritten from the repository contracts at `f3e7c0fa7bd827064a41c48a53c4db372840cf0f`. This is a mechanism reference, not a new validation result or a change to native semantics.

This page owns current lower producers, their eligibility, and the consumers allowed to use them. [Lower-bound mathematics](mathematics/lower-bounds.md) owns the derivations; [numerical closure](mathematics/numerical-closure.md) owns coefficient and endpoint distinctions. Historical numeric progress belongs to the original experiments and question-linked reports, not this mechanism page.

## Authority Rule

A contribution may raise a public lower, justify retirement, or support a gap only when its optimistic relation covers the actual requested action scope and source domain. An ordering value, restricted-envelope optimum, or numerically checked relation with no native bridge remains a different object.

The implemented proof manager composes compatible independently valid patterns by maximum. Addition requires a separate cost/decomposition argument. [CLM-0010](claims.md#clm-0010) explains the distinction.

Primary owners are `solver_proof_pattern_manager.hpp`, `solver_solve_bounds.cpp`, `solver_solve_carrier_pattern.cpp`, `solver_solve_operator_proof.cpp`, `solver_solve_envelope_proof.cpp`, `solver_solve_heuristics.cpp`, and the publication classifier.

## Current Patterns

| Component | Information and current role |
|---|---|
| Independent goal-cover floor | Optimistic action reach and completion cost; usable without a complete restricted search graph |
| Clean-carrier refinement | Rarity, goal subset, occupancy/capacity, terminal debt, tags/weights, and destructive effects where its eligibility proof applies |
| Operator lower | Proved action cost and survival/destruction relation followed by an optimistic compatible continuation |
| Envelope Bellman pattern | Uses completed action evidence under its coverage contract; unfinished computation retains independent fallback |
| Lower-only quotient | A private finite-model numerical consumer/checker on existing graph and ProofStore ownership |
| Native phase/retention producer | Supplies a native validity bridge for its declared domain, including the current default-off ordinary retention consumer |

Acquisition tables and continuation potentials use different coordinates. The proposal adapter must preserve that role; a coordinate conversion alone is not an admissibility proof. See [CLM-0016](claims.md#clm-0016).

## Coverage And Lower-Only Queries

`QuotientBellmanGraph::solve_lower/check_lower` uses the existing sparse rows, observed choices, dependencies, and memory owner. `LowerOnly` mode cannot issue an executable solve/projection. An ordinary uncertified row does not become valid lower evidence just because it is numerically available.

The query supplies canonical expected actions and a disjoint complete partition of explicit constraints and residual families. An action is represented by a complete declared row, a compatible independent scalar/family lower, or proved inapplicability. Unknown family members cannot disappear when one finite member is refined. Equal constraint counts do not establish equal action sets.

Independent boundary values remain distinct from jointly checked internal variables. A lower-only query does not require the incumbent's router to accept a frontier item. It requires the native lower relation and appropriate stopping assumptions. See [CLM-0012](claims.md#clm-0012).

A prior native lower need not be feasible inside a changed truncated model. Preserve it as independent evidence at maximum composition; do not force it into an incompatible candidate vector. See [CLM-0013](claims.md#clm-0013).

## Numerical acceptance and native validity

Candidate generation uses the shared sparse arithmetic. Acceptance checks finite nonnegative values against every raw represented inequality with exact binary dot products. The query records raw stored coefficients, an explicitly normalized reference, or an exact-binary model separately.

That acceptance establishes the declared numerical relation. A native producer must also establish coefficient provenance, terminal inclusion, action coverage, and validity across every represented native member. A certificate binds its complete request/model snapshot and relevant generations.

Zero-cost components may yield a weak checked finite lower. The result does not assert greatest-proper-policy convergence, infinity, or native exact closure. [CLM-0023](claims.md#clm-0023) and the numerical chapter explain why neither a small residual nor a familiar certificate type supplies missing premises.

## Conservative Slack

Unsupported effects and outside-domain continuations can use deliberately favorable fallbacks. Extra optimistic recovery, early cleanup, broader reach, or weaker blocker constraints can preserve lower validity while reducing usefulness. Removing a native alternative has the opposite direction unless it is independently retired.

A price-only relation needs a reason. An independent outside exit is a semantic relaxation; a candidate-price shortcut may merely defer expensive construction. Minimum-owning computational floors reactivate even at equality, and the changed model is solved before an older feasible vector ends refinement. [CLM-0019](claims.md#clm-0019) explains why a temporary floor is not necessarily a permanent ceiling.

## Native probabilistic relations

The support-only phase producer remains distinct from the probability-aware producer. A support-union model can intentionally grant all potentially introduced goals together and therefore be extremely weak; that limitation does not refute a richer stochastic lower.

The probability-aware producer preserves the clean projection's rarity, current goal mask, side occupancy, and the supported retention/crafted categories. Native integer pool statistics bound conditional events using satisfying weight and conservative blocker effects. Joint-goal caps use complete distinct-position assignments only when the retained/forced-goal, overlap, side-limit, and history premises hold.

Per-mask capacities are not automatically aggregate subset constraints. The final continuation values determine event minima and the distribution minimizing expectation. The producer rebuilds observed choices, successor minima, allocations, and relevant rows for the final potential, then checks the simultaneous system. A merely feasible or stale allocation can overstate the lower expectation. See [CLM-0014](claims.md#clm-0014) and [CLM-0015](claims.md#clm-0015).

Only value-independent geometry and compatible exact-mask event caps are reused within a preparation. This does not make them exact native kernels reusable for every value vector or a cross-request cache.

## Opt-In Ordinary Native Retention Lower

`SolveOptions::native_retention_lower` defaults off and is not exposed through the public product profiles or bindings at this snapshot. `SolveWork::Impl` prepares one compatible view in setup and reserves the additional proof budget within the total solver cap. `NativeRetention` contributes through the existing maximum-composition path.

The qualified frame is anchored by an exact goal fracture and couples the relevant unfractured region. Its reported scope covers the recorded side/goal domain and all Eldritch phases, with conservative handling of hidden exclusions. Generic influence, active metamods, additional fractures, veiled state, and unsupported restore memory remain outside its validated frame. Do not generalize its domain from the name “phase lower.”

Current retained facts include Scour's fracture preservation; side-specific Eldritch effects; removable crafted categories; Exalt non-exhaustion evidence; uniform Annul loss categories; and Alchemy's applied rarity distinct from its separately proved minimum refill occupancy. Unknown refill histories keep underfilled Rare outcomes instead of undoing the native application.

The ordinary lookup uses retained `AbstractState` observations and complete modifier-member masks, not one materialized representative. Ambiguous fracture identity, unsupported class members, failed preparation, or incompatible memory preserve the previous lower. A coupled fresh entry inside an anchored certificate is not automatically a general empty-start request certificate.

An identity-compatible whole-state lower for the full unchanged scope also lower-bounds every legal action and residual family. That supports compatible maximum consumption even while incremental generation remains open. [CLM-0011](claims.md#clm-0011) states the required premise; a restricted-program value cannot be used this way.

## Program composition and boundary evidence

The native mandatory-program composer charges setup once and streams complete integer exit weight. Every failure continuation needs compatible evidence. Primitive relations telescope through the supported program grammar with the correct observation and restore memory; an unsupported restore contract refuses rather than silently changing the request.

Positive exact-fresh recovery evidence is immutable and comes from its existing preparation owner. Internal regions may instead be checked jointly. A paid outside exit with zero continuation is a relaxation, not a native success or executable upper.

## Consumers And Failure

A local action retirement requires a valid action lower and a compatible proper executable upper at the same source/class, using the actual strict comparison and tie contract. A cheap root upper cannot stand in for an uncovered successor upper. Retirement creates no executable row and closes no other unknown action.

Public lower fallback for an open incremental graph uses independently valid patterns, including an eligible ordinary retention contribution. It never republishes the restricted graph value merely because that value is larger.

Inspect lower provenance, eligibility/refusal reasons, complete action coverage, preparation cost, consumer selections, and actual retired obligations. Keep component gain, whole-model gain, portfolio gain, ordinary consumption, and end-to-end exact-closure outcome separate. See [benchmarking](benchmarking.md).

## Source basis

This rewrite uses the [preceding reference](https://github.com/OliverOrton/poecraft2/blob/f3e7c0fa7bd827064a41c48a53c4db372840cf0f/docs/solver/lower-pruning.md) and [solver_quotient_lower.hpp](https://github.com/OliverOrton/poecraft2/blob/f3e7c0fa7bd827064a41c48a53c4db372840cf0f/engine/src/solver_quotient_lower.hpp), [2026-09-05-native-applied-reforge-preparation-v1](https://github.com/OliverOrton/poecraft2/blob/f3e7c0fa7bd827064a41c48a53c4db372840cf0f/docs/archive/2026-09-05-native-applied-reforge-preparation-v1/README.md), [2026-09-05-native-retention-lower-integration-v1](https://github.com/OliverOrton/poecraft2/blob/f3e7c0fa7bd827064a41c48a53c4db372840cf0f/docs/archive/2026-09-05-native-retention-lower-integration-v1/README.md). Mathematical links refer to the companion draft chapters and provisional claim IDs; they do not declare those claims accepted. Local implementation correspondence must be reconciled during integration.
