# Mathematical documentation drafts for the pinned v2 programme

**Governing plan:** `Solver-wide mathematical backbone and cumulative research workflow`, implementation plan v2 — lean operation. Its bytes have not been changed. `PLAN_PIN.json` identifies the exact plan and original package by SHA-256.

**Reviewed repository snapshot:** `OliverOrton/poecraft2` at `f3e7c0fa7bd827064a41c48a53c4db372840cf0f`.

This packet supplies documentation for the existing plan. It is not another implementation plan, a remote repository edit, or a claim that the programme is completed. Files under `repo-drafts/` already have their intended repository-relative paths.

## What is ready

| Intended path | Content | Integration treatment |
|---|---|---|
| `docs/solver/mathematical-model.md` | Target SSP, policy scope, terminal, costs, properness and output meanings | New substantive draft |
| `docs/solver/mathematics/README.md` | Question-directed reading and whole-solver correctness chain | New substantive draft |
| `docs/solver/mathematics/representations.md` | Exact quotients, optimistic relations, member quantifiers and identity | New substantive draft |
| `docs/solver/mathematics/policies.md` | Fixed-policy equations, absorption, observed choices, programs, retries and compilation | New substantive draft |
| `docs/solver/mathematics/lower-bounds.md` | Stopping proof, frontier/coupled models, coverage, composition, stochastic relations and ceilings | New substantive draft |
| `docs/solver/mathematics/search-and-resumption.md` | Local dominance, incomplete work, snapshot reuse, fairness and performance interpretation | New substantive draft |
| `docs/solver/mathematics/numerical-closure.md` | Coefficient layers, residuals, direction of checking and conditional exactness | New substantive draft |
| `docs/solver/claims.md` | 25 proposed claims with preconditions, arguments, dependencies and falsifications | New draft ledger; reconcile IDs and real acceptance |
| `docs/solver/research.md` | Three durable questions, six precise integration gaps, outcome profiles and lightweight research intake | New substantive draft; no fake generated status |
| `docs/_templates/solver-research-handoff.md` | Short report/receipt guidance | Copied unchanged from the pinned v2 package |
| `AGENTS.md` | Lean task-directed rules | Copied unchanged from the pinned `AGENTS.proposed.md`; merge with actual local instructions |
| `CLAUDE.md` | Shared-policy pointer and tool-specific boundary | Replacement candidate |
| `docs/README.md` | Navigation without chronological preamble | Replacement candidate; preserve relevant old anchors/evidence when merging |
| `docs/direction.md` | Product orientation and exact-closure objective | Replacement candidate |
| `docs/solver/README.md` | Separate mathematics and mechanism routes | Replacement candidate |

The long documents are reference material, not session preamble. No helper/function acquires an obligation to read the whole collection. The short entry pages route a task to its relevant argument.

## What Codex still needs to do

Follow the pinned plan, not a new process invented by this packet. Reconcile the documents with local changes; preserve original evidence; map important claims to actual producers, validators and consumers; add genuine acceptance or challenge events; and implement the planned narrow lint/reporting/reference/retirement work where it remains outstanding.

All 25 claim IDs are packet-local proposals and all initial histories are `open` for integration. This avoids inventing repository approval or an independent reviewer. Mathematical derivations are supplied; native applicability and public numerical interpretation must still be checked. The six GAP sections state exactly which bridges were not established here.

No `research-state.md` was handwritten. The v2 plan requires that view to be generated from real inputs. No reporting schema, CI job, runtime annotation, engine change, source removal, or model-checker installation is claimed in this packet.

Do not replace the whole existing documentation tree with `repo-drafts/`. Add the new owners and merge replacement candidates as the pinned migration plan specifies. Existing relative links outside this packet are listed in `checks/document_checks.json` for validation in the checkout.

## What was actually checked

`checks/math_examples.py` ran 33 exact synthetic arithmetic/counterexample checks. Its output is included. These examples are not a native crafting experiment or a universal proof checker. No native solve, native test suite, Simulator, external model checker, or public action was run.

The package's authored relative links, explicit anchors, claim IDs, metadata fields and acyclic logical dependencies were checked. Existing-repository dependencies and external URLs are distinguished from package-local checks; no blanket live-link audit is claimed.

The example script initially had a Python keyword used as a field name; it was corrected before the passing run. No native behavior or mathematical expected result was changed to make the checks pass.

Repository contracts and original literature are linked directly in the documents. Arguments reconstructed in this draft are not described as previously accepted native proofs or as novel research results. `sources.json` records the evidence scope.

## Small handoff to Codex

> Use these files as the initial documentation content for the already-pinned v2 programme. Do not generate a replacement plan or discard the supplied arguments in favor of empty headings. Check local scope, reconcile the 25 proposed claim IDs, preserve the six explicit gaps, merge the new/replacement files at their listed paths, and continue the remaining tooling, reporting, independent-reference, and evidence-preserving cleanup work from the governing plan. The packet does not authorize a solver-feature change or a push.
