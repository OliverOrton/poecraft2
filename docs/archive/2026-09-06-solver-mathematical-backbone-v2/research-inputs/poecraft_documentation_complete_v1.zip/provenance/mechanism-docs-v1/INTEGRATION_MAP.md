# File and integration map

| Intended destination | Treatment | Original knowledge retained |
|---|---|---|
| `.claude/agents/data-auditor.md` | Merge replacement | Optional instructions; not delegation authorization |
| `.claude/agents/doc-drift.md` | Merge replacement | Optional instructions; not delegation authorization |
| `.claude/agents/test-pipeline.md` | Merge replacement | Optional instructions; not delegation authorization |
| `docs/foundation/change-impact.md` | Merge replacement | Mechanism, scope, failure and source responsibilities; original history linked |
| `docs/foundation/solver-internals.md` | Merge replacement | Mechanism, scope, failure and source responsibilities; original history linked |
| `docs/foundation/solver-lab.md` | Merge replacement | Mechanism, scope, failure and source responsibilities; original history linked |
| `docs/solver/benchmarking.md` | Merge replacement | Mechanism, scope, failure and source responsibilities; original history linked |
| `docs/solver/flow.md` | Merge replacement | Mechanism, scope, failure and source responsibilities; original history linked |
| `docs/solver/lower-pruning.md` | Merge replacement | Mechanism, scope, failure and source responsibilities; original history linked |
| `docs/solver/publication.md` | Merge replacement | Mechanism, scope, failure and source responsibilities; original history linked |
| `docs/solver/request-action-scope.md` | Merge replacement | Mechanism, scope, failure and source responsibilities; original history linked |
| `docs/solver/resources-resume-replay.md` | Merge replacement | Mechanism, scope, failure and source responsibilities; original history linked |
| `docs/solver/scheduling-bellman.md` | Merge replacement | Mechanism, scope, failure and source responsibilities; original history linked |
| `docs/solver/states-carriers.md` | Merge replacement | Mechanism, scope, failure and source responsibilities; original history linked |
| `docs/solver/strict-closure.md` | Merge replacement | Mechanism, scope, failure and source responsibilities; original history linked |
| `docs/solver/telemetry.md` | Merge replacement | Mechanism, scope, failure and source responsibilities; original history linked |
| `docs/solver/transitions-reforge.md` | Merge replacement | Mechanism, scope, failure and source responsibilities; original history linked |
| `docs/solver/upper-authority.md` | Merge replacement | Mechanism, scope, failure and source responsibilities; original history linked |

## Narrow edits

| Supplied file | Destination/action |
|---|---|
| `integration-edits/decisions.append.md` | Append owner-approved decisions; do not replace the old decision ledger |
| `integration-edits/historical-index-notices.md` | Change introductions/navigation only; preserve historical entries and anchors |
| `integration-edits/docs-tooling-transition.md` | Supersede future-only placeholder only after real tool integration |
| `integration-edits/current-policy-conflicts.md` | Review concrete contradictions; do not change runtime semantics merely to match prose |

The governing plan, mathematical chapters, claim histories, root AGENTS/CLAUDE/map drafts, and short research handoff from the earlier packet remain unchanged. Generated research state, actual source annotations, code retirement, CI and reporting remain Codex implementation work.
