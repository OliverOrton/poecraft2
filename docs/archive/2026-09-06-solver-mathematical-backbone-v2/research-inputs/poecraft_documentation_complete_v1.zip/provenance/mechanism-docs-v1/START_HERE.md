# Additional mechanism and workflow documentation

**The lean-operation v2 implementation plan remains pinned and unchanged.** This packet supplies the next set of document drafts under that plan; it is not a new plan or a repository change. `PLAN_PIN.json` matches the previous mathematical packet.

**Reviewed source:** `OliverOrton/poecraft2` at `f3e7c0fa7bd827064a41c48a53c4db372840cf0f`.

## Ready to integrate

`repo-drafts/` contains 18 replacement candidates at their intended paths:

| Area | Files |
|---|---|
| Solver mechanism and data flow | `request-action-scope.md`, `states-carriers.md`, `transitions-reforge.md`, `scheduling-bellman.md`, `upper-authority.md`, `lower-pruning.md`, `strict-closure.md`, `publication.md`, `resources-resume-replay.md`, `telemetry.md`, `flow.md` under `docs/solver/` |
| Benchmark interpretation | `docs/solver/benchmarking.md` |
| Implementation/impact/operation references | `docs/foundation/solver-internals.md`, `change-impact.md`, `solver-lab.md` |
| Optional existing tool definitions | `.claude/agents/doc-drift.md`, `test-pipeline.md`, `data-auditor.md` |

`integration-edits/` contains four narrow merge inputs: append-only decisions; historical-index/active-index notices; a conditional future-tooling transition; and a source-supported conflict list. They are one-time integration material, not new recurring process files.

The first mathematical packet's 15 Markdown drafts are unchanged. This packet links to their chapters and the same 25 provisional claim IDs. Claim histories remain open; a mechanism-page link does not accept a theorem or establish its native premises.

## How to use it

Integrate these alongside the first mathematical packet, or use the combined package containing both sets. Reconcile newer local work before replacing a file. Preserve existing useful anchors, original experiments, measured numbers and hashes. Do not replace the entire docs tree or overwrite `docs/decisions.md`, `evidence.md`, `architecture-history.md`, or live HANDOFF with a historical copy.

The drafts separate current mechanism from historical result narration. They retain exact scope, row completion, properness, numerical provenance, lifetime, and failure distinctions. General arguments link to the mathematical chapters instead of being rederived here.

The benchmark draft explicitly labels the approved outcome policy separately from the legacy reporter's current implementation. The future-tooling edit applies only after the tool exists. No generated `research-state.md`, completed lint/CI feature, source removal, or native validation is claimed.

The three optional `.claude/agents` definitions remove stale instructions; no subagent was used to write them, and they do not authorize delegation in the pinned programme.

## Notable corrections

The old optional test agent forbids the configured WASM build on the assumption the SDK is absent. The replacement uses actual build/environment evidence. The data auditor stops treating file modification times as sufficient proof of semantic staleness. The Lab reference no longer calls PDR permanently resource-capped or repeats a stale engineering simulation policy.

The browser's implemented `Verify 10,000 runs` label is preserved in the flow reference. It is explicitly separate from engineering qualification in shared AGENTS. No runtime or UI behavior is changed by this packet.

## Checks and limits

Structural checks passed across the combined 33-document draft namespace: balanced code fences, provisional claim references, and 257 draft-to-draft links/anchors. The check lists 22 existing-repository link occurrences for reconciliation in the actual checkout. External links were not exhaustively fetched.

This is a source-contract rewrite, not an exhaustive re-audit of all named implementation paths. No engine build, native solve/test, Simulator, optional agent, or remote write was run. The earlier mathematical examples are unchanged and were not rerun merely for this document batch.

`manifest.json` records file hashes, destinations, and source basis. `checks/document_checks.json` records exactly what was checked. Use the normal intake/final response from the pinned plan; no second receipt ceremony is needed.

## Instruction to Codex

> Use this packet as additional authored content for the pinned v2 plan. Merge the mechanism, benchmark, source-map, change-impact, and Lab replacements against current local code and the first mathematical drafts. Reconcile provisional claim IDs and retain their open status until genuinely reviewed. Apply the append-only/conditional edits only as stated; preserve historical evidence and live sequencing. Continue the tooling, report generation, reference, and verified cleanup work already selected by the plan. Do not regenerate these docs from empty headings or claim that importing prose completes the remaining implementation. Do not push.
