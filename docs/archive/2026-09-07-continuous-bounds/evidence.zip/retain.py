"""Retain existing run evidence; never launches an experiment."""
import hashlib
import gzip
import json
from pathlib import Path
import subprocess
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[2]
RUN = Path(__file__).resolve().parent
DEST = ROOT / "docs/active/2026-09-07-continuous-bounds"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert not (RUN / "active-process.json").exists(), "A run is still active"
assert not (RUN / "cancel").exists()
files = [p for p in RUN.iterdir() if p.is_file() and p.suffix in (".json", ".txt", ".py", ".cpp")]
with ZipFile(DEST / "evidence.zip", "w", ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(files):
        archive.write(path, path.name)
    archive.write(ROOT / "out/2026-09-07-relation-construction/coverage-compact.stdout.txt",
                  "control/coverage-compact.stdout.txt")
    archive.write(ROOT / "docs/archive/2026-09-07-relation-construction-v1/coverage-development.json",
                  "control/coverage-development.json")

for name, destination in (("retained-slot-exact.json", "reference.json"),
                          ("final-checked280-exact.json", "checked-subsolution-reference.json")):
    (DEST / destination).write_bytes((RUN / name).read_bytes())

changed = subprocess.check_output(
    ["git", "diff", "HEAD", "--name-only", "--", "engine", "apps/web/test", "bindings/wasm"],
    cwd=ROOT, text=True).splitlines()
source = {name: sha(ROOT/name) for name in changed}
patch = subprocess.check_output(
    ["git", "diff", "HEAD", "--", "engine", "apps/web/test", "bindings/wasm"], cwd=ROOT)
(DEST / "implementation.patch.gz").write_bytes(gzip.compress(patch, mtime=0))
receipts = {p.stem.removesuffix(".process"): json.loads(p.read_text())
            for p in RUN.glob("*.process.json")}
assert all(not p["survivor"] for p in receipts.values())
binary_paths = ["build/engine/poecraft_solver_benchmark.exe", "build/engine/poecraft_quotient_lower_probe.exe",
                "out/2026-09-07-continuous-bounds/baseline-bin/poecraft_solver_benchmark.exe",
                "out/2026-09-07-continuous-bounds/baseline-bin/poecraft_quotient_lower_probe.exe",
                "out/2026-09-07-continuous-bounds/recovery-bin/poecraft_solver_benchmark.exe"]
wasm_files = subprocess.check_output(["git", "ls-files", "*poecraft*.wasm", "*poecraft*.mjs"],
                                     cwd=ROOT, text=True).splitlines()
provenance = dict(
    baseline_commit="a1b85956d4c438ab3ea92ea114a3f1138c505467",
    source_identity=source, implementation_patch_sha256=hashlib.sha256(patch).hexdigest(),
    evidence_zip_sha256=sha(DEST/"evidence.zip"),
    binary_sha256={name: sha(ROOT/name) for name in binary_paths + wasm_files},
    input_sha256={name: sha(ROOT/name) for name in [
        "docs/archive/2026-09-04-free-value-bellman-research/native-goal.json",
        "docs/archive/2026-09-04-free-value-bellman-research/native-economy.json",
        "fixtures/solver-quality-ladder/v1/manifest.json"]},
    run_receipts=receipts,
    resumption="Usage-limited campaign stopped; Oliver explicitly authorized normal finishing work after 18:00, with no subagents. Actual resume clock 2026-09-08T04:02:13Z (21:02 Vancouver). No automatic continuation.",
    timing_identity="Earlier additive control and recovery binaries retained by SHA. Final native source hashes bind the resumed slot/Bench/checked treatments. Earlier uncommitted fixture corrections are diagnostic, not standalone speedup claims.",
    push_status="not pushed; local checkpoint only")
(DEST / "provenance.json").write_bytes((json.dumps(provenance, indent=2)+"\n").encode("utf-8"))
print(f"Retained {len(files)} raw files and {len(receipts)} process receipts")
