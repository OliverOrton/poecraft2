# Repository design and integration

## Decision

Use the existing documentation architecture and add only two standing files.
The missing item is a concise **current-capability projection**, not another
research history. Most recent mathematical results and scoped negatives already
appear in `docs/solver/research.md` and the canonical chapters. The projection
helps a new session reach those owners without reconstructing their chronology.

The design below is proposed for the W audit. It is not already on the reviewed
main. If a later revision introduces an equivalent owner, reconcile and reuse it
instead of creating a second current-status or standards document.

| Owner | Sole responsibility | What must not migrate here |
|---|---|---|
| `AGENTS.md` | Shared operating constraints and bootstrap entry pointer | Benchmark history or per-programme implementation details |
| New `docs/solver/research-standards.md` | Stable research/planning and cross-lane discipline | Duplicated proofs, current leaderboards, client-specific timeout constants |
| New `docs/solver/current-status.md` | Reviewed current capability/status navigation | Raw receipts, active scheduling, new proof authority |
| `HANDOFF.md` | Active/closed programme, continuation, process and allowance pointer | A second global capability table |
| One programme living record | Chronology, decisions, actual validation and source/evidence ledger | Universal rules copied into every checkpoint |
| Canonical mathematical/mechanism chapters and claims | Arguments, assumptions, implementation correspondence and status history | Chat-specific orchestration |
| Existing generated `research-state.md` | Declared historical quantitative series | Handwritten current global status |

### Resolve the existing instruction conflict explicitly

`docs/solver/research.md#knowledge` currently says not to replace the arrangement
with another database, queue **or status document**. Adding a snapshot without
changing that sentence would create contradictory repository instructions.
Replace that prohibition narrowly, preserving its intent, along these lines:

> Generated result views keep their existing quantitative ownership. Do not add
> another database, queue or measurement ledger. `current-status.md` is the one
> compact, source-linked projection of current capabilities; it does not replace
> receipts, claims, generated views or HANDOFF's sequencing authority.

Likewise the existing handoff template rejects a “new mandatory session.” Replace
that phrase with the user-selected general fresh-session policy, while retaining
the small-fix exception and continuity for interrupted execution.

## Minimal AGENTS addition

Insert after “Start with the task,” adjusting only to avoid duplicate wording:

> For substantive solver research, normally start a fresh planning session and a
> fresh execution session. Read `docs/solver/research-standards.md`,
> `docs/solver/current-status.md`, and HANDOFF's selected programme before the
> relevant source and mathematical premises. Already supplied, verified-current
> text need not be fetched twice. Check the snapshot's reviewed code against the
> actual available revision; do not infer that archived work remains selected.
> A continued session preserves process handles, decisions and spent budgets.
> Small fixes still need no new research programme.

Leave mechanics ownership, protected path `0`, local/no-push behavior, sequential
work, validation and usage-conservation rules intact. Do not install global
configuration, hooks or model-specific instructions.

## Other surgical edits

1. `docs/README.md` and `docs/solver/README.md`: add a brief “fresh substantive
   session” route and links to standards/status. Keep their maps optional.
2. `docs/solver/research.md`: add top navigation, amend the status prohibition,
   and add explicit historical scoping to ambiguous present-tense old paragraphs.
   Do not rewrite original findings to make them current.
3. `docs/_templates/solver-research-handoff.md`: merge the supplied short template;
   preserve its “use only needed fields” rule and original-input integration.
4. `docs/foundation/solver-internals.md`: add the shared selective producer and
   Current service source owners to the table; distinguish its original source
   basis from sections subsequently maintained. This is not a file-splitting task.
5. `docs/active/README.md`: make it a pointer to HANDOFF and current-status. Its
   statement that nothing is actively executing may be true; the arbitrary old
   role-parametric emphasis is not an effective newest-work guide.
6. `HANDOFF.md`: at W start identify W as selected and P as closed with limitations;
   at W close summarize reconciled state, remaining unknowns and recommended next
   decision. Recommendations do not extend P's exhausted 24-run allowance.

Do not scatter capability tables across these indexes. A link is sufficient.
Only amend another mechanism/product paragraph when W identifies an actual
unqualified current claim there. Preserve original archives and generated files.

## Snapshot freshness without perpetual churn

Record a full `reviewed code` SHA, scope and links to actual qualification. The
commit containing the documentation will necessarily be newer: do not attempt a
self-referential “this file equals current HEAD” hash. Documentation-only commits
need no benchmark. A code change triggers review of affected rows, not wholesale
requalification or blind date updates. Check relevant local/unpushed differences
separately before starting work.

Each quantitative summary names its lane, target, profile and original receipt.
A result at a previous build remains evidence at that build. “No later regression
recorded” is not “qualified at all subsequent commits.” A current source fact and
an older measurement can coexist when the limitation is explicit.

Updates belong with substantive capability/default/qualification changes and
programme closeout. The committing executor updates the affected rows and links;
the next Pro checks the relevant delta. No daily bot, generated dashboard or
new per-claim registry is required. CI status is checked live for the actual head,
not a permanent green badge in the snapshot.

## Minimal session context

The standing bootstrap is AGENTS + standards + snapshot + HANDOFF, then the
selected milestone and its relevant source/math. Aim for roughly 2,500–3,500
words before task-specific context, not a hard token cap. Never trim away a
proof premise to satisfy that target. Whole claims/research/architecture histories
are not mandatory reading.

For local Codex, verify repository identity and relevant working-tree metadata
without reading protected `0`. Global and nested AGENTS overrides may apply.
OpenAI documents AGENTS instruction discovery; arbitrary linked Markdown is not
therefore automatically loaded. The root pointer must explicitly direct the
read. Pro working through a connector explicitly fetches these files and pins
its available main. Neither role assumes access to the other's unpushed files.

For needed mathematical exports, use existing `solver_knowledge context` with
selected claims/questions. It preserves premises and source visibility; its
export is neither a new proof nor a reason to dump all claims into every session.

## Cold-start acceptance

Given only the four standing files and a selected question, the next session
must locate the current code, lane capabilities, active scope/budget, relevant
owners and known qualification gaps. W checks this with a deterministic question
sheet, not an extra paid agent or a new benchmark. Actual fresh-session operation
is observed on the next real programme; do not claim that reading the checklist
proves that every future model will follow it.

Sources: current AGENTS, documentation ownership, research intake/knowledge,
benchmarking and tooling owners at `ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c`; pinned links in SOURCES.md.
