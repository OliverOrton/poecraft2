# Fresh-session workflow and baseline reconciliation

Reviewed main: `ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c` — **Add shared selective completion with private solver consumers**.

This package designs repository support for Oliver's fresh-session workflow. It
selects a **documentation/evidence reconciliation programme**, not continuation of
the previous P0–P9 runtime work. No repository changes or new solver experiments
were made while preparing it.

## Use

This conversation supplies the Pro plan for W0–W5. Start its fresh Codex execution
with [CODEX_AUDIT_PROMPT.md](CODEX_AUDIT_PROMPT.md) once Oliver selects the audit.
After W finishes, use [NEXT_PRO_PROMPT.md](NEXT_PRO_PROMPT.md) to plan the first
substantive solver programme from the reconciled repository. No redundant Pro
reconstruction of this same audit is required unless main changes its scope.
Neither prompt silently activates the future research recommendation.

## Small permanent footprint

Add two documents: `docs/solver/research-standards.md` and
`docs/solver/current-status.md`. Update the existing handoff template and a few
routing/ownership sentences. Do not add a knowledge database, status generator,
agent framework or parallel hierarchy of research documents.

| File | Purpose |
|---|---|
| [REPOSITORY_CHANGES.md](REPOSITORY_CHANGES.md) | Ownership, integration edits, freshness and minimal bootstrap |
| [AUDIT_PLAN.md](AUDIT_PLAN.md) | W0–W5 first fresh-session programme and completion criteria |
| [AUDIT_REGISTER.md](AUDIT_REGISTER.md) | Seeded evidence issues and historical/chat intake map |
| [NEXT_RESEARCH_DECISION.md](NEXT_RESEARCH_DECISION.md) | Ranked, conditional recommendation after reconciliation |
| [Standards draft](drafts/docs/solver/research-standards.md) | Concise standing rules |
| [Current-status draft](drafts/docs/solver/current-status.md) | Actual current capabilities and essential caveats |
| [Handoff template draft](drafts/docs/_templates/solver-research-handoff.md) | Reuses the existing template, including two bootstrap prompts |
| [SOURCES.md](SOURCES.md) | Pinned source basis and review limits |

Drafts use intended repository-relative links. Their links to existing repository
owners need the repository checkout; the ZIP does not duplicate that library.
The snapshot is a reviewed draft, not a claim that the later local-ledger audit
has already occurred.

## First programme boundary

W0–W5 may edit instructions, documentation, navigation and the living audit
record. It may read existing local reports and run applicable documentation/link/
traceability checks. **Zero new timed solver cases, zero Simulator campaigns and
no solver/runtime behavior changes are selected.** A real source defect becomes
a specifically scoped subsequent implementation decision, not an excuse to
expand this baseline audit indefinitely.

No entire historical packet is a prerequisite read. Preserve the current
repository's working rules, mathematical owners, immutable evidence and budgets.
