# First substantive programme after reconciliation

**Recommendation, not selected execution.** The W audit must finish its source
and evidence reconciliation first. Do not automatically continue P0–P9 or restart
its 24-run allowance.

## Primary candidate: ordinary Current evidence and incumbent continuity

Question: under one fixed ordinary clean request and profile, does Current retain
its valid lower evidence and make its strongest already-constructed, independently
checked controller available at the correct pre-Finish boundary without an
optional consumer changing the preceding work unexpectedly?

Why this is first, based on reviewed main:

- P added substantial new proof gating, yet its ordinary lower outputs differ
  from U. The actual profile/source explanation is unresolved in the summaries.
- The real Current selective-service runs never checked a proposal; a costly
  availability scan was then removed without post-fix comparison.
- Earlier and current product early-Finish controls show useful checked policies
  can exist much earlier in some profiles. Those observations are not proof that
  the new native service sees the same artifact at the same boundary.
- The known selective full-root candidate costs 379,815.68 against Current's
  85,558.71. Enabling more checks of that same inferior graph is not itself an
  economic strategy improvement.

The programme should test the actual evidence lifecycle, not select a new
heuristic, low-level cache, global sweep rule or unconditional early service.
Relevant owners are the current proof capability/retirement/publication paths,
IncumbentPortfolio, the compact progress boundary and selective-service gate.

### Audit-dependent selection

| Audit outcome | First substantive programme |
|---|---|
| Ordinary proof use or artifact authority is inconsistent under truly matching inputs | Correct that concrete consumer/identity issue first with a native failing fixture; preserve the ordinary exact control. |
| Lower differences are explained, but pre-Finish availability/optional-service noninterference remains unqualified | Run the bounded Current continuity programme described here. |
| Both boundaries are already qualified by later compatible evidence | Do not rerun them. Select private-to-product Finder qualification next, or the native fill-domain research if user priority is strategy quality. |

### Proposed research contract, to finalize in the next Pro session

First reproduce one real availability/state transition in a focused native
fixture. Distinguish finite working value, materialized proposal, completed
independent evaluation, owned compatible artifact and public usable result.
A constant-time availability flag may be a scheduling hint, but the real consumer
still validates the artifact and its identity. A root-only upper never supplies
an arbitrary statewise continuation or global lower.

Test Current ordinary versus optional-service-requested but not yet started
under identical fixed work. Any change before service requires an explained
source path. Preserve hidden/context and target semantics, exact control,
complete cancellation and the old best artifact on failure. A disabled service
must not trigger expensive graph scans from a progress predicate.

Only after that fixture, propose a **new allowance of at most four timed native
runs**: one matched case pair with reversed-order confirmation where performance
is claimed. This allowance is not granted by W. Use one relevant A4/A5 case,
not both automatically; include an affected Finder/lifecycle regression at the
cheapest appropriate existing test level. Probe the actual source revision after
the gate fix, not the old mismatched execution.

Success means a traceable pre-Finish checked artifact, preserved ordinary proof
provenance, and no unexplained degradation before service. A useful earlier
identical result is a service improvement; a candidate check that loses fairly
is not an economic gain. Do not force an inferior full-root candidate into the
portfolio merely to demonstrate “both consumers.”

## Second candidate: private Finder-to-WASM activation parity

The current private selective grammar's A5 result is much better than the
existing product Finder grammar's result, but the runtimes/activation differ.
A source-matched test-only worker qualification of the supported selective grammar
could provide user-facing value without inventing another algorithm. It must
exercise the actual grammar, original clean target and aggregate resource limits,
not merely rebuild WASM and run the old selector. Early Finish, cancellation,
no-policy and capped cases remain part of the result. Public activation remains a
separate owner decision. This is capability delivery, not a new native search win.

Choose this ahead of new grammar when W shows the relevant backend and Current
continuity are trustworthy and the remaining gap is genuinely product activation.

## Third candidate: native reached-domain completion research

The rejected Exalt-fill candidates supply a concrete next research boundary:
the source option chosen at one item failed semantic admission at a reached
3-prefix/1-suffix state with goal mask 15. Determine whether the intended control
needs a more precise initiation partition, a different bound native option at
that state, or an unavailable programme. Do not repeat threshold tuning or weaken
reached-entry validation. Keep the rejected candidate as semantic failure, not an
evaluated expensive policy.

A useful result would be one role-relative completion contract that covers all
actually reached member states, preserves real probabilities and paid recovery,
and has one complete original-root economic witness. Both lanes can consume the
same producer once their actual callers are qualified. Do not demand an exact
symmetry quotient or train a model before this programme can be constructed.

## Why the old momentum is not the decision rule

Target-neutral Current is now present; implementing it again is stale work.
The broad heterogeneous-symmetry hypothesis is still open, but the previous
pair-stop/cache/preparation negatives need a new expensive native consumer before
another implementation. Ring memory-only work and O scheduling changes did not
improve their scoped controllers. S was inactive in its measured lifecycle.
Neither a larger beam nor a hybrid label fixes a missing native programme domain.

The audit's final recommendation should name one candidate, its updated evidence,
first discriminating test, explicit budget request and what result would redirect
it. These alternatives are not a new automatic multi-track plan. The project goal
of extending exact closure remains; new positive coverage proof research should
be selected only after valid target-specific model/consumer evidence is available.
