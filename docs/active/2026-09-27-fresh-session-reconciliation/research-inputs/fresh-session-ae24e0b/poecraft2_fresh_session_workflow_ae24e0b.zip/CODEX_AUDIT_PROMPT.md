# Execute W0–W5 when Oliver selects this audit

Repository: OliverOrton/poecraft2.
Reviewed remote main: ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c.
Selected work: fresh-session repository support and a rigorous current-baseline
reconciliation. **Do not continue the old P0–P9 solver implementation.** Its
24 timed native invocations are exhausted; a session reset does not renew them.

Read applicable AGENTS, actual HANDOFF and this packet's REPOSITORY_CHANGES.md,
AUDIT_PLAN.md and AUDIT_REGISTER.md. Read the three drafts when integrating them.
Treat drafts as proposals to reconcile, not already authoritative files. Verify
package paths/hashes before import; inspect supplied code before execution.

Check actual remote main, local HEAD, relevant uncommitted work and nested rules.
Preserve protected root `0` without inspecting, staging, editing or deleting it.
No reset/cleanup or push. Work sequentially without subagents. Use one W living
record and short HANDOFF; existing mathematical, claims, evidence and generated
research owners stay in place.

Implement only two new standing documents, the existing handoff-template update
and the small routing/ownership edits specified in REPOSITORY_CHANGES. Resolve the
anti-status and old session-template wording explicitly. Keep standards compact;
current status is a source-linked capability projection, not a new measurement
ledger or scheduler. Existing generated research-state.md is not edited by hand.

Execute W0–W5. Required reconciliation includes Current neutral support now being
implemented, private versus public Finder grammars, P6 implemented-but-unreached
service and post-fix missing timing, ordinary lower differences, original report
failure/expectation distinctions, P4 fill versus retained reroll/repair, unrun
24-attempt comparison, and named historic/chat propositions already integrated
canonically. Do not diagnose a bug from a prose discrepancy. Do not normalize away
an inconvenient failure, import the whole conversation or rename old negatives.

Read existing local ledgers first. **No new timed solver case, no Simulator, no
solver/runtime/ABI behavior edit, and no new proof or public activation is selected.**
Use appropriate existing doc/link/knowledge checks. A real code problem gets a
specific source/fixture proposal and affects the next programme; do not let this
become an unbounded engine audit. Record unavailable local artifacts precisely.

Finish with the amended docs, reviewed-code scope, a concise completed register,
actual validation and limitations, coherent local commit and no-push status.
Check the four-document cold-start questions without another agent. HANDOFF records
whether anything is running and the next recommended decision. Read
NEXT_RESEARCH_DECISION only to formulate that recommendation; do not execute it.
This W audit is the first fresh Codex programme; another Pro preflight duplicating
the present review is not required unless the source delta changes the scope.
