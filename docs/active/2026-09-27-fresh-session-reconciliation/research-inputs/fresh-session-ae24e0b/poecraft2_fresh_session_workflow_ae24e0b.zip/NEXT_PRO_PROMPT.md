# First fresh Pro research session after W0–W5

Repository: OliverOrton/poecraft2.

Read actual main metadata, AGENTS.md, docs/solver/research-standards.md,
docs/solver/current-status.md and HANDOFF.md. The workflow package was reviewed
at ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c; use the audit's later reviewed source,
not that older pin by default. Do not reread documents already supplied with
verified-current contents. Read W's completed audit register and only relevant
source/math and original receipts.

Choose the first substantive solver programme from the reconciled evidence.
The prior recommendation was ordinary Current proof/artifact continuity and
pre-Finish availability, conditional on the lower-value and profile audit. The
alternatives were private selective Finder-to-WASM qualification or the concrete
reached-domain fill-programme failure. Do not automatically resume the old
sustained P0–P9 packet, reimplement neutral Current, or force a known inferior
root candidate into Current.

Produce a focused implementation plan with actual owners, hypotheses and native
witnesses, Current/Finder/runtime applicability, proof/upper separation, unchanged
problem identity, resource and experiment allowance, mandatory deliverables and
conditional stops. Keep known negatives and genuine unknowns. No new timed run or
runtime change is authorized just by reading this prompt; propose the required
allowance. Repository memory replaces the old long conversation, not native
verification or necessary mathematical premises.
