# W0–W5: verified baseline and fresh-session support

## Selected programme

Repository: OliverOrton/poecraft2. Reviewed main: `ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c`.
Purpose: install a small, coherent bootstrap and reconcile the current statements
that subsequent solver work will rely on. This is a documentation/evidence audit,
not another algorithm experiment. It supersedes automatic continuation of the old
P0–P9 plan without deleting that programme's results or unfulfilled obligations.

**Allowed:** named source/metadata/report reads; small documentation and
navigation edits; canonical clarification supported by evidence; existing
traceability/link checks; a local coherent commit when Oliver selects execution.
**Not selected:** solver behavior changes, dependency upgrades, CI-framework
rewrites, new generated status infrastructure, public activation, new timed
native cases, Simulator runs, or a fresh general literature campaign.

The timed-native allowance for W is zero. Reading old ledgers is not a new run.
P's 24-run allowance is exhausted and is not inherited as a new allowance. A
small behavioral ambiguity that cannot be settled from source/records is an
explicit unresolved item and proposed focused fixture for the next programme.

## W0 — Pin, locate and preserve

Pin actual remote main; Codex records local HEAD and relevant dirty changes.
Inspect applicable root/nested instructions, excluding protected `0` content.
Reconcile any delta from this packet before editing. Check same-head CI once and
at final delivery if still pending; no routine polling loop or duplicate runs.
Record active processes from the existing owner, not from an old chat. The current
HANDOFF reports none; a fresh local check may discover otherwise.

Read AGENTS, HANDOFF, documentation ownership, research intake/knowledge, and the
latest sustained record. Inspect source only for concrete current capability
claims. Existing U/K/E records answer historical contrasts; do not recursively
read all their imported plans. Establish one W living record containing the audit
register, checked evidence paths and decisions. Do not create a second receipt
format or copy the full package to every directory.

Exit: available revision/local limits, scope, source/evidence availability,
zero new-run budget, and provisional register recorded.

## W1 — Agree and install the small documentation roles

Add the two standing drafts after reconciling their rows. Amend AGENTS and the
existing anti-status/no-mandatory-session sentences together so instructions do
not conflict. Preserve HANDOFF as the sole sequencing owner. Keep generated
research state untouched. Merge the existing handoff template, rather than
adding several overlapping bootstrap guides in the repository.

Draft status can remain visibly provisional during the audit. Keep standards
approximately 1,000–1,200 words and status approximately 800–1,000 words; these
are maintenance targets, not mathematical truncation limits. Short root routing
should replace repeated prose rather than grow an agent manual.

Exit: a new reader has an unambiguous four-document route and distinct roles for
current truth, operating rules, programme state, arguments and original evidence.

## W2 — Reconcile actual lane and runtime capabilities

For each row of the snapshot, join source implementation, actual consumer,
recorded qualification and public exposure. Inspect native options/admission,
shared source inventory, product request/worker mapping and the relevant tests.
Do not infer runtime reachability from a class, enum or source file alone.

Cover Current ordinary clean and its exact-capable contract; Current neutral L/R
and its zero-only bounded contract; existing public Finder grammar; private
conditional/selective grammar; shared producer/validator; default-off Current
service; hypothetical hybrid. Keep target semantics distinct from proof profile.
W does not certify the entirety of any proof implementation from static browsing.

Resolve source-vs-qualification gaps explicitly: current P6 guard fix lacks a
post-fix timed receipt; P8 tests existing product modes, not every private feature;
private neutral support supersedes U's old before-work refusal. Verify what final
WASM hash/build record establishes and what it does not. Preserve code-present,
consumer-reached, native-qualified and product-qualified as separate fields.

Exit: every current capability statement has cited source/receipt or a named
qualification limitation. No implication that Current acquired Finder's economic
result, that shared construction is a hybrid, or that bounded R is exact R.

## W3 — Reconcile evidence and unfinished promises

Read compact projections of the existing U/P ledgers before raw large reports.
Required issues are seeded in AUDIT_REGISTER.md. In particular:

- Reconcile ordinary Current U lowers 198.8335/405.3694 against P3 values
  21.7725/36.4885. Resolve actual retention/proof flags, command, executable,
  source, stop time and publication provenance. An unexplained difference remains
  open; neither declare a regression nor normalize it away.
- Separate A5's envelope-support reliability class from its valid checked graph;
  preserve A3's partly explained old coarse stop.
- Match P3 A4 repaired/unrepaired source identities and original expectation exits;
  source reporting fixes do not relabel historical failures.
- Map old P mandatory requirements to implemented/qualified, implemented-unreached,
  substituted, semantic refusal, censored, unrun or deferred. Specifically preserve
  failed fill candidates, surviving reroll/repair, unrun 24-attempt comparison,
  unqualified Current service and ineligible local placement.
- Distinguish observed first finite values, independent verification, usable owned
  artifact and final delivery. Audit clock origins and sample loss.

Keep immutable output directories intact. If a required local artifact is absent,
record path/hash and the specific unanswered question; do not regenerate it under
W or claim an empty record. The packet's summaries are leads, not replacement
native evidence. No complete replay workspace is inferred from a final graph.

Exit: all high-impact inconsistencies are resolved or visibly bounded by missing
evidence, and the next research decision can distinguish them.

## W4 — Preserve useful context without copying conversations

Compare the named intake propositions in AUDIT_REGISTER.md to canonical owners.
Most are already integrated. Preserve any genuinely missing argument or negative
with its premises, source epoch and status. Mark unverified chat claims as such.
Never turn the older dirty-state concern into a present causal finding; never
turn multiple derivative chat descriptions into independent replications.

Historical outcome paragraphs can remain historical. Fix ambiguous present-tense
navigation with an as-of qualifier and a successor link rather than editing the
original experiment. Keep math and claim status histories intact. Old structural
line counts were approximate and included uncommitted edits; they are not current
profiling or instructions to split the codebase.

Update only the affected source-map rows, top-level navigation and canonical
sentences. No wholesale archive movement, broad file splitting or universal
renaming. If the named inputs contain no missing substantive result, record that
finding; do not manufacture debt to justify document additions.

Exit: each named contribution is incorporated, already present, scoped-negative,
open or unavailable, with a single durable owner.

## W5 — Verify bootstrap and recommend, then stop

Run existing link/knowledge checks appropriate to changed docs. For claims touched
semantically, preserve full conditions and compare the relevant history; otherwise
do not allocate new theorem IDs. A successful lint is traceability, not native
or mathematical verification. No build/WASM rerun solely for Markdown changes.

From only AGENTS, standards, status and HANDOFF, verify that the following are
answerable without an archive walk: actual reviewed code; selected work and budget;
clean versus R; Current neutral versus ordinary; Finder private versus public;
exact versus checked; hybrid status; last useful and failed mechanisms; material
unknowns; next source owner. Follow one source chain for each high-risk claim.
This is a deterministic editorial cold-start check, not an additional model run.

Complete a short per-programme requirement-to-outcome table and update the draft
label only to the extent checked. Record excluded source areas and unavailable
raw reports. Commit locally when executing this selected audit, with no push
unless separately requested. HANDOFF says W closed or interrupted, actual active
processes, and the next recommended decision. Do not start that solver programme.

## Decision/stop conditions

A routine document inconsistency is fixed here. A runtime correctness question is
reduced to its exact claim/source/evidence and blocks affected *claims*, not every
unrelated documentation improvement. Ambiguous intended mechanics belongs to
Oliver. External account/runtime configuration is not changed.

The audit is complete when the selected register has no unlabelled high-impact
claim, the bootstrap works without historical reconstruction, and the next
programme is chosen conditionally from evidence. It need not prove the entire
solver correct or settle all open mathematical problems.
