# Seeded audit register — evidence, not verdicts by intuition

These issues were identified during the read-only Pro review at `ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c`.
Codex should verify the relevant local data, then maintain the final register in
one W living record. Source labels below resolve in SOURCES.md. “Recorded” means
the repository reports it; the Pro review did not rerun native qualification.

| ID | Present evidence and risk | Required reconciliation / disposition |
|---|---|---|
| W-01 | `research.md#knowledge` prohibits another status document, while fresh bootstrap now needs a compact capability projection. S04 | Amend the ownership rule explicitly; one status projection, no duplicate measurement database or sequencing owner. |
| W-02 | U's historical Current R refusal appears alongside P's implemented neutral support. S06/S07/S12 | Mark the former as an as-of result with a successor pointer. Preserve the refusal record; do not tell a new session to implement a missing profile that is now present. |
| W-03 | P's original fill-plus-recovery milestone required real fill; fill variants failed semantic admission, while reroll/repair was retained. S06/S17 | Record original requirement as not achieved; record the useful substitute separately. This is not a failure of all completion or Exalt semantics. |
| W-04 | Ordinary U A4/A5 lowers were 198.83350/405.36940, whereas P3 ordinary rows report 21.7725/36.4885, with the strong cost references unchanged. S06/S07 | Inspect actual source/build, flags, producer activation, retained proof, time and publication normalization. Neither a confirmed regression nor a harmless discrepancy is established yet. Do not pair old lowers with a new trajectory. |
| W-05 | P6 Current service real runs checked no candidate before Finish. A per-step scan was then replaced; no post-fix run exists. S06/S13 | Separate implemented caller, first finite estimate, available checked incumbent, service reachability, and economic qualification. Post-fix recovery remains unmeasured. |
| W-06 | Private selective Finder A5 is 379,815.68; actual P8 public/current Finder grammar is 320,800,932.13. S06/S14 | Not a same-grammar regression. Verify exact frontend/protocol flag mapping and build/runtime. A rebuilt WASM does not expose every private mode. |
| W-07 | A5 P3 three-arm source freeze is shared; repaired A4 neutral rows use a different freeze and carry original expectation failures. S06 | Publish valid capability findings but no pure same-build A4 target-effect or timing claim. Reporting fixes remain later source changes, not rewritten receipts. |
| W-08 | A5 reliability refusal coexists with a checked policy; the cause is now partially localized. A3 other_resource_cap mapping is explained but the initiating coarse stop remains unknown. S06 | Preserve graph validity, solver termination, envelope support, corpus expectation and process exit as distinct facts. Mark the exact residual unknown. |
| W-09 | Shared selective TUs are in engine-sources, but the older internals map omits their distinct ownership. S09/S10 | Add narrow producer/service rows and correct header scope. Do not split files based on a historical size report. |
| W-10 | `research-state.md` is generated RQ-002 history, not global live status. S05/S08 | Keep generated data intact; add navigation to the new reviewed projection, not handwritten edits to generated history. |
| W-11 | `docs/active/README.md` emphasizes an old role investigation; current HANDOFF is a much newer closed programme. S03/S11 | Keep active index navigational; no contradictory second active plan. Folder name `active` is not proof a programme is still authorized. |
| W-12 | Many recent mathematical arguments and negatives already exist canonically. S04/S16 | Map named chat inputs before importing. Add only genuinely absent substance; no blanket claim that months of reasoning were lost. |
| W-13 | Prior P budget is 24/24; diagnostic 24-attempt comparison and P6B were not completed. S03/S06/S17 | Mark exact unrun/ineligible requirements. Fresh session is not extra authorization. W uses zero timed runs. |
| W-14 | Tooling docs contain host-specific wait observations; inherited prompts can turn them into assumed universal runtime facts. S01/S08/S18 | Standards keep behavioral rules; installed client limits verified as needed. No global configuration/security changes or invented background completion. |
| W-15 | New programme may inherit broad “exact solver fixed,” “both improved,” or “hybrid available” phrasing from chat. S06/S12/S14 | Replace with the capability tuple: lane, target, proof profile, grammar, actual consumer, runtime, qualification, activation. Shared helper existence is not a result in both lanes. |

## P0–P9 outcome mapping to retain

| Requirement | Recorded end-state | What not to infer |
|---|---|---|
| Neutral Current L/R | Implemented privately and returns checked bounded policies | Positive R lower/exact closure or competitive neutral A4 search |
| Full selective fill controller | Rejected at reached native programme entry | More-expensive evaluated candidate or impossible native fill |
| Reroll/repair Finder | Retained; qualified native A5 L improvement over K | Improvement over Current or public selective Finder activation |
| Current producer caller | Implemented, real measured runs did not reach checker | Economic failure of a checked Current candidate, or qualified service |
| Post-scan-fix Current result | Unrun | Measured correction of the earlier overhead |
| Larger 24-attempt Finder comparison | Unrun after budget exhaustion | It was compared because the option exists |
| P6B local placement | Its precursor did not exist | A completed local strategy failed economically |
| Release bundle and lifecycle | Built and existing modes exercised | All private grammar/profile combinations qualified |

This mapping records incomplete outcomes without accusing Codex of ignoring the
budget. The prior plan explicitly allowed reduced blocked dispositions, but the
original and substituted deliverables must remain distinguishable.

## Named historical/chat intake

The supplied handoffs are historical research inputs, not new source authority.
Use the canonical locations below before requesting or copying another archive.

| Input | Substance to preserve | Existing destination / bounded check |
|---|---|---|
| Dirty-intermediate hypothesis at a7ea53c | Strict final cleanliness differs from progress; occupancy ties and debt examples are hypotheses | `research.md` later J/K/E/U/P dispositions and policy/search chapters. O negative, S gate-inactive, G Finder-specific; no general “fixed” claim. |
| Independent finder handoff | Separate aggressive policy discovery from proof; all accepted policies still checked; heuristic pruning need not be proof-safe | Finder architecture and canonical policies/representation chapters. Preserve intermediate figures as historical and no ML promise. |
| Broad heterogeneous goal-role idea | Shared proposal/computation structure may exist without equal probabilities or values | `research.md` scoped pair-stop, memo, G0, D1 and strict-preparation findings plus representation mathematics. Do not broaden a low-level negative. |
| Old structural report | Giant coroutines/ownership and repeated utility concerns | `solver-internals.md` and current source owners. Supplied counts used approximate parsing and uncommitted code; historical counts are not a current profile. |
| September 15 recurrence/response audit | First-exit equations, changed recurrence, checked policy vs MDP lower, overlap-before-cache rule | Existing policy, representation, lower and numerical chapters. The presence of a derivation does not establish a profitable native cache. |
| Recent sustained packet | Current neutral support plus two-consumer selective completion ambition | P living record and W requirement/outcome mapping. Proposed success targets and future branches are not achieved results. |
| Fresh-session request | Durable repo memory; standards, compact status, low-usage bootstraps, reconciliation first | New two documents and existing handoff/AGENTS routing. This is the newly selected workflow change. |

For each input, record incorporated/already-present, missing argument, open,
refuted-at-scope, or unavailable. A missing original may warrant a precise request
for that source; it never licenses reconstructing its measurements from memory.
Only the named inputs are in scope. Do not claim to have searched every old chat.

## Local evidence to read first

Use the actual ledger's artifact paths, not invented sibling filenames:

```text
out/dual-lane-target-support/U4/current-ordinary-L/ledger.json
out/sustained-dual-solver/P0/finder-L-expectation/ledger.json
out/sustained-dual-solver/P3/
out/sustained-dual-solver/P5/
out/sustained-dual-solver/P6/    [resolve actual run paths from P record/ledger]
out/sustained-dual-solver/P7/finder-control-final-8-L/
out/sustained-dual-solver/P7/finder-selective-final-8-L/
out/sustained-dual-solver/P8/
out/strategy-finder/F4/current/cases/rp-a3-product8-long240.json
```

Directory hints are not claims that every path exists locally. The P6 records may
be organized under the P6/P7 batch's actual output roots. Read a ledger before
following file names. If absent, preserve the exact availability limitation.

## Format for a completed audit row

`claim / source-and-revision / original receipt-or-unavailable / actual lane and
profile / scope of validation / discrepancy / disposition / canonical change /
remaining question / recommendation impact`.

Keep this in the one W record; a duplicate CSV or new evidence service is not
required. Native values are not recomputed from prose. Observational-only labels
must not be silently upgraded during summary writing.
