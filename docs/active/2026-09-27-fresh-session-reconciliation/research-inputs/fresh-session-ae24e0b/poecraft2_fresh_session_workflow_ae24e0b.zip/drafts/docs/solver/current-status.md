# Solver current status

**Draft reviewed capability snapshot — validate during the first reconciliation.**
Reviewed code: `ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c`.
This page summarizes cited source and recorded results; raw local ledgers were
not independently re-executed for this draft. It is not a new proof, benchmark
ledger, generated research series or sequencing owner. [HANDOFF](../../HANDOFF.md)
owns the selected work, running processes and remaining experiment allowance.

A later documentation-only commit need not change this code revision. On a
relevant code/runtime change, review the delta and refresh affected rows; do not
transfer old qualification to a new build by editing the heading. Follow each
record for its actual executable, scope and measured revision.

## Goal, authority and lane map

Public v1 retains a clean final explicit-affix target. Dirty intermediate items
remain representable. Private coverage R allows extras; explicit-clean E is
normalized to L only where its equivalence conditions hold. Target shape and
proof profile are separate. Checked fixed-policy value is not exact closure.

| Lane or capability | Native status | Proof/result scope | Product/WASM status |
|---|---|---|---|
| Current ordinary clean L/E | Implemented; strong A4/A5 checked policies | Existing positive-lower and exact-closure capability; cited A4/A5 results are bounded | Existing default clean path exercised |
| Current target-neutral L/R | Privately implemented in P1/P2 | Zero global lower, selected-policy checking; `closure_unavailable_by_profile` | New private profile not exposed by cited Calculator probes |
| Finder existing clean grammar | Implemented and checked | Feasible policies only; no global lower/optimality | Existing experimental product mode exercised |
| Finder conditional-retention L/R | Private native qualification | Original-request check and native programme-entry validation | Not established as the product grammar by the cited probes |
| Finder selective-retention | Private A5 L reroll/repair qualification | 691 reached entries checked; no proof authority | Compiled shared sources do not imply transport activation |
| Current shared selective service | Default-off consumer implemented | Root-only candidate checking/adoption; no real measured pre-Finish candidate reached its checker | Not qualified for activation |
| End-to-end hybrid/portfolio mode | No qualified public mode established by these owners | Requires a separately qualified checked-artifact handoff | Do not equate shared producer reuse with hybrid support |

Sources: [sustained record](../active/2026-09-26-sustained-dual-solver/README.md),
[proof capability](../../engine/src/solver_solve_contracts.hpp),
[Current service](../../engine/src/solver_solve_selective_completion.cpp),
[source inventory](../../engine/engine-sources.txt).

## Baseline anchors, not one universal leaderboard

| Recorded context | Checked expected Chaos | Interpretation |
|---|---:|---|
| Current ordinary clean A4 / A5 | 3,746.13194 / 85,558.70619 | Retained strong root controllers; bounded, not new exact solves |
| Finder A5 clean, same-source eight attempts: retained-side / selective | 524,079.69865 / 379,815.67816 | 27.53% within-Finder reduction; selective remains about 4.44 times Current |
| Current neutral A5 L / R | 85,558.7062 / 33,109.8416 | Same-freeze semantic contrast; R is an easier, different target |
| Current neutral A4 L / R | 15,772,148.6906 / 588,884.9957 | Checked fallback capability; not competitive and not fully source-matched with ordinary A4 |
| Actual P8 Calculator Finder, existing grammar | 320,800,932.13 | A different activated grammar from private selective; not evidence that private selective regressed |

The [P record](../active/2026-09-26-sustained-dual-solver/README.md) owns commands,
hashes, timing and qualifications. The [U record](../active/2026-09-26-dual-lane-target-support/README.md)
remains historical: its refusal of neutral Current was superseded by P.
The old coverage-only optimum is not a clean-goal certificate. Runtime, case,
start rarity, source and profile must accompany every reused number.

## Unresolved or incompletely qualified

**Ordinary lower reconciliation:** U reports A4/A5 lowers 198.83350/405.36940;
P3 ordinary arms report 21.7725/36.4885. Resolve producer activation, flags,
source, time and publication provenance from the ledgers. Do not call this a
confirmed regression or silently join an old lower to a new run's upper.

**Current pre-Finish service:** P6 real runs performed zero candidate checks.
The costly availability scan was removed afterward; no post-fix matched replay
exists. Source-level repair is not measured recovery. P6B local placement was
ineligible, not an economic negative.

**Programme domain:** Exalt-fill variants failed reached-entry semantic admission
at c10, occupancy 3/1, goal mask 15, and were removed. Reroll/repair survived.
That does not reject the Exalt mechanic or qualify the original fill milestone.

**Reporting:** A5's supported graph coexists with an unsupported-envelope
observation linked to `primitive_renewal_expected_actions_exceed_simulator_cap`.
A3's historical `other_resource_cap` mapping is explained, but its original coarse
stop source is not. Repaired reporting code does not retroactively change exits.

**Evidence limits:** the 24-attempt Finder comparison is unrun; A4 neutral
repairs changed the executable before comparison with ordinary A4; no new public
goal semantics or selective-grammar activation is established. P8 rebuilt WASM
and tested existing Current/Finder lifecycle, not every private combination.

## Do not restart without a new premise

O's same-mask occupancy-order ablation returned the identical A5 controller.
S was measured inactive in 19,667 A5 calls, not measured under an active gate.
The role pair-stop, same-attempt memo, low-level reforge template and later
preparation pilots are scoped negatives; they neither establish broad symmetry
savings nor refute all heterogeneous-role strategies. Ring capacity trials did
more work without improving the selected ordinary policy. The aggregate
[research dispositions](research.md) link their originals.

The 24-run P0–P9 allowance is exhausted. A new session does not renew it.
Detailed unresolved claims remain in [research](research.md#open-obligations)
and the claim histories, not in a growing duplicate list here.

## Maintenance

Refresh only changed capabilities, qualification scope and high-impact warnings
when their programme closes; HANDOFF links this page rather than copying it.
Keep roughly one short page of capabilities plus essential caveats. Move detail
to its existing owner. Do not hand-edit [generated research state](research-state.md).
Remove the draft label only after the reconciliation records checked sources and
explicitly outstanding evidence. Live CI and local process status must be read
at the next task, not inferred from this snapshot.
