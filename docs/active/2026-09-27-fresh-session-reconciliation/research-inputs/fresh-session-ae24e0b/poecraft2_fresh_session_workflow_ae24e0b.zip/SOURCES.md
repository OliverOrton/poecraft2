# Source basis and review limits

Repository: OliverOrton/poecraft2. Pinned main: `ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c`.
Review is read-only and targeted to workflow, source ownership, capability status
and the latest programme. Code snippets and recorded test outcomes do not amount
to a new exhaustive native correctness audit.

| ID | Pinned owner | Inspected scope / use |
|---|---|---|
| S01 | [AGENTS.md](https://github.com/OliverOrton/poecraft2/blob/ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c/AGENTS.md) | Full; current operating, authority, validation and conservation rules. |
| S02 | [docs/README.md](https://github.com/OliverOrton/poecraft2/blob/ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c/docs/README.md) | Full; documentation ownership and navigation. |
| S03 | [HANDOFF.md](https://github.com/OliverOrton/poecraft2/blob/ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c/HANDOFF.md) | Full; P closeout, exhausted budget, no active process as reported. |
| S04 | [docs/solver/research.md](https://github.com/OliverOrton/poecraft2/blob/ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c/docs/solver/research.md) | Returned main text and source ranges 360–750; durable questions, recent dispositions, intake and anti-status rule. |
| S05 | [docs/solver/research-state.md](https://github.com/OliverOrton/poecraft2/blob/ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c/docs/solver/research-state.md) | Returned generated-view text; scope is the historical RQ-002 series, not live global capability. |
| S06 | [docs/active/2026-09-26-sustained-dual-solver/README.md](https://github.com/OliverOrton/poecraft2/blob/ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c/docs/active/2026-09-26-sustained-dual-solver/README.md) | Full; P implementation, source freezes, outcome limits, private/product distinction and raw paths. |
| S07 | [docs/active/2026-09-26-dual-lane-target-support/README.md](https://github.com/OliverOrton/poecraft2/blob/ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c/docs/active/2026-09-26-dual-lane-target-support/README.md) | Source lines 60–135; original U values, refusals and validation, now historical. |
| S08 | [docs/foundation/tooling.md](https://github.com/OliverOrton/poecraft2/blob/ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c/docs/foundation/tooling.md) | Source lines 1–240; existing owners, request identities, compact reads, serial batches and installed-client waiting. |
| S09 | [docs/foundation/solver-internals.md](https://github.com/OliverOrton/poecraft2/blob/ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c/docs/foundation/solver-internals.md) | Source lines 1–240; existing architecture/ownership map and scoped evidence. |
| S10 | [engine/engine-sources.txt](https://github.com/OliverOrton/poecraft2/blob/ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c/engine/engine-sources.txt) | Full; shared compilation inventory including new selective producer/service. |
| S11 | [docs/active/README.md](https://github.com/OliverOrton/poecraft2/blob/ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c/docs/active/README.md) | Full; current active-work navigation and older emphasis. |
| S12 | [engine/src/solver_solve_contracts.hpp](https://github.com/OliverOrton/poecraft2/blob/ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c/engine/src/solver_solve_contracts.hpp) | Source lines 1–140; actual neutral/ordinary proof capability type. |
| S13 | [engine/src/solver_solve_selective_completion.cpp](https://github.com/OliverOrton/poecraft2/blob/ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c/engine/src/solver_solve_selective_completion.cpp) | Source lines 1–290; real Current generation/check/validation consumer. Not an end-to-end dynamic audit. |
| S14 | [apps/web/src/app/engine-protocol.ts](https://github.com/OliverOrton/poecraft2/blob/ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c/apps/web/src/app/engine-protocol.ts) | Source lines 485–580 and 710–850; public request, limits and progress vocabulary. Use S06 for recorded activation; not a whole-file absence proof. |
| S15 | [docs/_templates/solver-research-handoff.md](https://github.com/OliverOrton/poecraft2/blob/ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c/docs/_templates/solver-research-handoff.md) | Full; existing lean template and conflicting old session phrase. |
| S16 | [docs/solver/README.md](https://github.com/OliverOrton/poecraft2/blob/ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c/docs/solver/README.md) | Full; mathematical/mechanism routing. Named chat intake is compared against S04 and its canonical links, not assumed lost. |
| S19 | [docs/solver/benchmarking.md](https://github.com/OliverOrton/poecraft2/blob/ae24e0bb8797fb953cb8b9eb5c8ef040fbba203c/docs/solver/benchmarking.md) | Source lines 1–200; identity, clocks, qualifications, reporter and selected-context commands. |

## Supplied and external material

**S17 — Supplied prior programme:** `MASTER_PLAN.md` and `EXECUTION_PROTOCOL.md`
from `poecraft2_sustained_dual_solver_plan_184b934.zip`, explicitly attached in the
conversation and read through the file tools. They define original P deliverables,
stop rules and the cumulative 24-run budget. Their outcome is determined by S06,
not inferred from a plan's verbs. The W package does not re-import their contents.

The other supplied dirty-state, finder-architecture, structural and recurrence
handoffs were available as full text in the conversation. Their stated revisions
are historical. The mapping in AUDIT_REGISTER preserves their concepts and
caveats; a native result remains linked to its repository record. This review did
not search every prior conversation or claim exhaustive chat recovery.

**S18 — Official instruction discovery:** [OpenAI's AGENTS.md guidance](https://developers.openai.com/codex/guides/agents-md),
currently redirected to [ChatGPT Learn](https://learn.chatgpt.com/docs/agent-configuration/agents-md).
It documents instruction-chain discovery from global/project/nested files at
session start, including overrides and size limits. It does not establish that
all linked Markdown is automatically loaded. The recommendation is to keep the
root pointer small and make the additional reads explicit, not to raise global
limits or change security settings. No claim depends on a particular model name.

## Reviewed workflow runs

- [Windows 36299764501](https://github.com/OliverOrton/poecraft2/actions/runs/36299764501):
  initially in progress; subsequently completed successfully for this head. The
  job's build and test steps were successful at the final read.
- [Solver knowledge 36299764437](https://github.com/OliverOrton/poecraft2/actions/runs/36299764437):
  completed successfully for this head at the recorded read.

These are hosted run observations, not newly run local validation. Knowledge lint
cannot certify mathematical truth; CI success is not evidence for an unexercised
private mode or previously unrun economic comparison.

## Evidence availability

The Pro review did not inspect the implementation machine's ignored `out/`
ledgers, rebuild native/WASM, execute a solver/candidate check, run a Simulator,
train a model or edit repository files. S06 reports those earlier activities.
W's local-ledger reads are required precisely where summaries leave the question
unresolved. Draft current-status entries remain scoped accordingly.

Only package formatting, internal links/known repository targets, checksums and
archive integrity are validated here. No toy mathematical suite is manufactured
for a documentation workflow task.
