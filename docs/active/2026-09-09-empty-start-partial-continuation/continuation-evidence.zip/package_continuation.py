"""Freeze existing resumed evidence; no builds, solves, or Git mutations."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root = Path(__file__).resolve().parents[2]
run = Path(__file__).resolve().parent
destination = root / 'docs/active/2026-09-09-empty-start-partial-continuation'
assert not (run / 'active-process.json').exists()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

source_paths = ['engine/src/solver_solve_constructive.cpp',
    'engine/src/solver_solve_incremental.cpp', 'engine/src/solver_phase_probability.cpp',
    'engine/benchmarks/solver_quotient_lower_probe.cpp', 'engine/tests/test_solver_solve.cpp',
    'apps/web/test/empty-start-retention-wasm.test.ts']
patch = subprocess.check_output(['git', 'diff', '--binary', 'HEAD', '--', *source_paths], cwd=root)
(run / 'continuation-final.patch').write_bytes(patch)
binary_paths = ['build/engine/poecraft_solver_benchmark.exe',
    'build/engine/poecraft_quotient_lower_probe.exe', 'build/engine/poecraft_engine_tests.exe',
    'bindings/wasm/dist/poecraft_engine.wasm', 'bindings/wasm/dist/poecraft_engine.mjs']
sources = {p: sha(root / p) for p in source_paths + binary_paths}
identity = {'base': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'files_sha256': sources, 'engine_patch_sha256': sha(run / 'continuation-final.patch'),
    'native_timing_source_note': 'C14/C16/C17 preceded restoration of two UTF-8 comments only; final rebuild uses identical executable code.',
    'wasm_source_note': 'C15 WASM built after final eager-retention source and UTF-8 comments were restored.'}
(run / 'continuation-final-source.json').write_bytes((json.dumps(identity, indent=2)+'\n').encode('utf-8'))
files = [p for p in run.glob('C*') if p.name[0] == 'C' and p.name[1:2].isdigit()
         and p.is_file() and p.suffix in ['.json', '.txt', '.patch']]
files += [p for d in run.glob('C*-strategy.json') for p in d.glob('*.strategy.json')]
files += [run / p for p in ['run.py', 'package_continuation.py', 'continuation-final.patch', 'continuation-final-source.json']]
assert len(files) == len(set(files))
processes = {p.name: json.loads(p.read_text(encoding='utf-8')) for p in files if p.name.endswith('.process.json')}
assert all(not p['survivor'] for p in processes.values())
assert json.loads((run / 'C15-wasm-primary.json').read_text(encoding='utf-8'))['status'] == 'passed'
archive = destination / 'continuation-evidence.zip'
manifest = {}
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as package:
    for path in sorted(files):
        relative = path.relative_to(run).as_posix()
        package.write(path, relative)
        manifest[relative] = {'sha256': sha(path), 'bytes': path.stat().st_size}
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
    assert all(hashlib.sha256(package.read(name)).hexdigest() == record['sha256'] for name, record in manifest.items())
provenance = {**identity, 'evidence_zip_sha256': sha(archive), 'files': manifest,
    'preserved_previous_evidence_sha256': sha(destination / 'evidence.zip'),
    'subagents_spawned': 0, 'run_owned_processes_stopped': True,
    'process_outcomes': {name: {key: p[key] for key in ['exit_code','timed_out','canceled','survivor','wall_ms']} for name,p in processes.items()},
    'limitations': ['C8 WASM gate failed before its separate abandon control; cleanup completed.',
        'C9 readiness treatment was rejected and removed; its policy was evaluated but worse.',
        'C4 old-code fixture has one intentional failure; do not classify it as passing.',
        'No primary five-goal exact closure, user-export reproduction, rendered UI review, broad suite or Simulator claimed.']}
(destination / 'continuation-provenance.json').write_bytes((json.dumps(provenance, indent=2)+'\n').encode('utf-8'))
print(json.dumps({'archive_bytes':archive.stat().st_size,'files':len(files),'processes':len(processes),'sha256':sha(archive)}))
